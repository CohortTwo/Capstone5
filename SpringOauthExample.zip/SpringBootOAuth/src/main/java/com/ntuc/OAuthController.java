package com.ntuc;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class OAuthController {
	
	@GetMapping("/login")
	public String showLogin() {
		return "login";
	}
	
	@GetMapping("/login-error")
	public String loginerror() {
         return "login-error";
	}
	
	@RequestMapping("/")
	public String showmain() {
		return "index";
	}

}
