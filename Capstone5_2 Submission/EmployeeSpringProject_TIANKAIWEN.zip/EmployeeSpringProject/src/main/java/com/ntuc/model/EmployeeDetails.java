package com.ntuc.model;

import javax.persistence.*;

@Entity
public class EmployeeDetails {

    @Id
    private Long empDetailsId;

    @Column
    private ContactDetails contactDetails;

    @OneToOne(fetch = FetchType.LAZY)
    @MapsId
    @JoinColumn(name = "empDetailsId")
    private Employee employee;

    public Long getEmpDetailsId() {
        return empDetailsId;
    }

    public void setEmpDetailsId(Long empDetailsId) {
        this.empDetailsId = empDetailsId;
    }

    public ContactDetails getContactDetails() {
        return contactDetails;
    }

    public void setContactDetails(ContactDetails contactDetails) {
        this.contactDetails = contactDetails;
    }

    public Employee getEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }
}
