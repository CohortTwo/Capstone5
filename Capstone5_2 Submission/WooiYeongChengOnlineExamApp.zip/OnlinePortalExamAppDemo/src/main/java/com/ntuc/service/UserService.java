package com.ntuc.service;

public interface UserService {

}
