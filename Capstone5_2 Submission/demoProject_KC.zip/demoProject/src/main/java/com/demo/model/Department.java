package com.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Department {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer deptid;
	
	@Column(length = 30, nullable = false, unique=true)
	private String deptname;

	//Constructors
	public Department() {
		super();
	}
	
	public Department(Integer deptid, String deptname) {
		super();
		this.deptid = deptid;
		this.deptname = deptname;
	}

	public Department(Integer deptid) {
		super();
		this.deptid = deptid;
	}

	public Department(String deptname) {
		super();
		this.deptname = deptname;
	}

	//Getters and Setters
	public Integer getDeptid() {
		return deptid;
	}
	public void setDeptid(Integer deptid) {
		this.deptid = deptid;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((deptid == null) ? 0 : deptid.hashCode());
		result = prime * result + ((deptname == null) ? 0 : deptname.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Department other = (Department) obj;
		if (deptid == null) {
			if (other.deptid != null)
				return false;
		} else if (!deptid.equals(other.deptid))
			return false;
		if (deptname == null) {
			if (other.deptname != null)
				return false;
		} else if (!deptname.equals(other.deptname))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return deptname;
	}
	
}
