package com.ntuc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlinePotalExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlinePotalExamApplication.class, args);
	}

}
