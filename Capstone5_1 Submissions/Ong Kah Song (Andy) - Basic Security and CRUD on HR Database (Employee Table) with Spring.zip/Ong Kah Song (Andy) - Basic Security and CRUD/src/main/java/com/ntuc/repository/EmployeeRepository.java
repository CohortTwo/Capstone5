package com.ntuc.repository;

import java.util.List;

import com.ntuc.model.Employee;

public interface EmployeeRepository {

	List<Employee> findAll();

	Employee findOne(Integer employeeId);

	Employee save(Employee employee);

	void deleteById(Integer employeeId);

	Employee update(Employee employee);
}
