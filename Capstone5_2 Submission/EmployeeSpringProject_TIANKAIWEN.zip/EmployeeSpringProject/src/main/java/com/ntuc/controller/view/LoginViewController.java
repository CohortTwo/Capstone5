package com.ntuc.controller.view;

import com.ntuc.security.model.AppUser;
import com.ntuc.service.AppUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletResponse;
import java.util.Optional;

@Controller
public class LoginViewController {

    @Autowired
    private AppUserService appUserService;

    @GetMapping("/login")
    public String loginPage(){
        return "login";
    }

    @GetMapping("/forget_password")
    public String forgetPasswordPage() { return "login/forgetpassword"; }

    @PostMapping("/reset_password")
    public String resetPassword(@RequestParam("username") String username,
                                @RequestParam("password") String password,
                                @RequestParam("confirmPassword") String confirmPassword,
                                Model model) {


        AppUser appUser = appUserService.findAppUserByUsername(username);

        if(appUser != null){
            boolean isSame = appUserService.validatePassword(password,confirmPassword);
            if(isSame){
                appUserService.updateAppUserWithNewPassword(appUser,password);
            }
            else {
                model.addAttribute("passwordNotMatch", true);
                return "login/forgetpassword";
            }
        }
        else{
            model.addAttribute("invalidUser",true);
            return "login/forgetpassword";
        }
        model.addAttribute("success",true);
        return "login/forgetpassword";
    }

}
