package com.ntuc.model;

import java.math.BigDecimal;
import java.time.LocalDate;
// import java.time.format.DateTimeFormatter;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.boot.autoconfigure.batch.BatchProperties.Job;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "employees")
public class Employee {
    @Id
    private Integer employeeId;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate hireDate;
    private Integer jobId;
    private BigDecimal salary;
    private Integer manager_id;
    private Integer department_id;

    public Employee() { }

    public Employee(
            Integer employeeId,
            String firstName,
            String lastName,
            String email,
            String phoneNumber,
            LocalDate hireDate,
            Integer jobId,
            BigDecimal salary,
            Integer manager_id,
            Integer department_id ) {
        this.employeeId = employeeId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.hireDate = hireDate;
        this.jobId = jobId;
        this.salary = salary;
        this.manager_id = manager_id;
        this.department_id = department_id;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public LocalDate getHireDate() {
        return hireDate;
    }

    public void setHireDate(LocalDate hireDate) {
        this.hireDate = hireDate;
    }

    public Integer getJobId() {
        return jobId;
    }

    public void setJobId(Integer jobId) {
        this.jobId = jobId;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }

    public Integer getManager_id() {
        return manager_id;
    }

    public void setManager_id(Integer manager_id) {
        this.manager_id = manager_id;
    }

    public Integer getDepartment_id() {
        return department_id;
    }

    public void setDepartment_id(Integer department_id) {
        this.department_id = department_id;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((department_id == null) ? 0 : department_id.hashCode());
        result = prime * result + ((email == null) ? 0 : email.hashCode());
        result = prime * result + ((employeeId == null) ? 0 : employeeId.hashCode());
        result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
        result = prime * result + ((hireDate == null) ? 0 : hireDate.hashCode());
        result = prime * result + ((jobId == null) ? 0 : jobId.hashCode());
        result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
        result = prime * result + ((manager_id == null) ? 0 : manager_id.hashCode());
        result = prime * result + ((phoneNumber == null) ? 0 : phoneNumber.hashCode());
        result = prime * result + ((salary == null) ? 0 : salary.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Employee other = (Employee) obj;
        if (department_id == null) {
            if (other.department_id != null)
                return false;
        } else if (!department_id.equals(other.department_id))
            return false;
        if (email == null) {
            if (other.email != null)
                return false;
        } else if (!email.equals(other.email))
            return false;
        if (employeeId == null) {
            if (other.employeeId != null)
                return false;
        } else if (!employeeId.equals(other.employeeId))
            return false;
        if (firstName == null) {
            if (other.firstName != null)
                return false;
        } else if (!firstName.equals(other.firstName))
            return false;
        if (hireDate == null) {
            if (other.hireDate != null)
                return false;
        } else if (!hireDate.equals(other.hireDate))
            return false;
        if (jobId == null) {
            if (other.jobId != null)
                return false;
        } else if (!jobId.equals(other.jobId))
            return false;
        if (lastName == null) {
            if (other.lastName != null)
                return false;
        } else if (!lastName.equals(other.lastName))
            return false;
        if (manager_id == null) {
            if (other.manager_id != null)
                return false;
        } else if (!manager_id.equals(other.manager_id))
            return false;
        if (phoneNumber == null) {
            if (other.phoneNumber != null)
                return false;
        } else if (!phoneNumber.equals(other.phoneNumber))
            return false;
        if (salary == null) {
            if (other.salary != null)
                return false;
        } else if (!salary.equals(other.salary))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "Employee [department_id=" + department_id + ", email=" + email + ", employeeId=" + employeeId
                + ", firstName=" + firstName + ", hireDate=" + hireDate + ", jobId=" + jobId + ", lastName=" + lastName
                + ", manager_id=" + manager_id + ", phoneNumber=" + phoneNumber + ", salary=" + salary + "]";
    }
}

//	public static Employee formToEmployee(EmployeeForm form) {
//        /* manager_id is column that can be null */
//		String rawManagerId = form.getManagerId().getText().trim();
//		Integer managerId = rawManagerId.equals("") ? 
//			null : Integer.valueOf(rawManagerId);
//
//        /* LocalDate.parse() will not parse single character day or month. For
//         * example, 1 has to be 01, 5 be 05...etc. */
//        String month = form.getHireMonth().getText();
//        String day = form.getHireDay().getText();
//        month = month.length() == 1 ? "0" + month : month;
//        day = day.length() == 1 ? "0" + day : day;
//
//		return new Employee(
//			Integer.valueOf(form.getEmpId().getText()), 
//			form.getFirstName().getText(),              	
//			form.getLastName().getText(),               	
//			form.getEmail().getText(),                  
//			form.getPhone().getText(), 
//			LocalDate.parse(
//				form.getHireYear().getText() + "-" + 
//				month + "-" + day, 
//				DateTimeFormatter.ISO_DATE),
//			form.getJobId().getSelectedIndex() + 1, 
//			Float.valueOf(form.getSalary().getText()), 
//			managerId, // Either an Integer obj or null
//			form.getDeptId().getSelectedIndex() + 1 );
//	}
//}

