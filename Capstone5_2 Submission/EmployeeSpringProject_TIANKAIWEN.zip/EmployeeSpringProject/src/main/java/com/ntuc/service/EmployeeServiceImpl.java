package com.ntuc.service;

import com.ntuc.io.CollectionExportable;
import com.ntuc.io.OpenPdfTableExporter;
import com.ntuc.io.SuperCsvExporter;
import com.ntuc.model.Employee;
import com.ntuc.model.EmployeeExportDTO;
import com.ntuc.repository.EmployeeDetailsRepository;
import com.ntuc.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private EmployeeRepository employeeRepository;
    private EmployeeDetailsRepository employeeDetailsRepository;

    @Autowired
    public EmployeeServiceImpl(EmployeeRepository employeeRepository, EmployeeDetailsRepository employeeDetailsRepository){
        this.employeeRepository = employeeRepository;
        this.employeeDetailsRepository = employeeDetailsRepository;
    }

    @Override
    public List<Employee> showEmployees() {
        List<Employee> employeeIds =  employeeRepository.findAll();
        return employeeIds;
    }

    @Override
    public Optional<Employee> showEmployeeById(Long id) {
        return employeeRepository.findById(id);
    }

    @Override
    public Long addEmployee(Employee employee) {
        return employeeRepository.save(employee).getEmpId();
    }

    @Override
    public void modifyEmployee(Employee employee, Long id) {
        employeeRepository.saveAndFlush(employee);
    }

    @Override
    public void removeEmployee(Long id) {
        employeeRepository.deleteById(id);
    }

    @Override
    public Page<Employee> showEmployeesByPaging(int pageNo, String dir, String field, String keyword){
        Sort sort = Sort.by(field);

        if(field !=null && !field.isEmpty()){
            sort = Sort.by(field);
            if(dir != null && !dir.isEmpty()) {
                if(dir.equalsIgnoreCase("asc"))
                    sort = sort.ascending();
                else
                    sort = sort.descending();
            }
        }

        Pageable pageable = PageRequest.of(pageNo-1, 5,sort);
        if(keyword!=null && !keyword.isEmpty()) {
            return employeeRepository.findAll(keyword,pageable);
        }
        return employeeRepository.findAll(pageable);
    }

    @Override
    public List<Employee> showDepartmentsByNameLike(String keyword) {
        if(keyword.isEmpty() || keyword == null){
            return employeeRepository.findAll();
        }
        return employeeRepository.findAllByNameContaining(keyword);
    }

    @Override
    public void exportToCsv(PrintWriter writer, List<Employee> employees) {
        List<EmployeeExportDTO> employeeExportDTOS = employees.stream().map(EmployeeExportDTO::new).collect(Collectors.toList());
        CollectionExportable<EmployeeExportDTO,Void> exportable = new SuperCsvExporter(writer);
        exportable.export(employeeExportDTOS);
        return;
    }

    @Override
    public void exportToPdf(OutputStream os, List<Employee> employees) {
        List<EmployeeExportDTO> employeeExportDTOS = employees.stream().map(EmployeeExportDTO::new).collect(Collectors.toList());
        CollectionExportable<EmployeeExportDTO,Void> exportable = new OpenPdfTableExporter(os,Employee.class);
        exportable.export(employeeExportDTOS);
        return;
    }


}
