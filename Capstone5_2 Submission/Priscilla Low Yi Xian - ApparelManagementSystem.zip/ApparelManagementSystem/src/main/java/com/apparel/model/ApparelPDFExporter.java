package com.apparel.model;
import java.awt.Color;
import java.io.IOException;
import java.util.List;
 
import javax.servlet.http.HttpServletResponse;
 
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;
 
 
public class ApparelPDFExporter {
    private List<Apparel> listApparel;
     
    public ApparelPDFExporter(List<Apparel> listApparel) {
        this.listApparel = listApparel;
    }
 
    private void writeTableHeader(PdfPTable table) {
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(Color.DARK_GRAY);
        cell.setPadding(5);
         
        Font font = FontFactory.getFont(FontFactory.HELVETICA);
        font.setColor(Color.WHITE);
         
        cell.setPhrase(new Phrase("Apparel ID", font));
        
        table.addCell(cell);
         
        cell.setPhrase(new Phrase("Type", font));
        table.addCell(cell);
         
        cell.setPhrase(new Phrase("Price", font));
        table.addCell(cell);
         
        cell.setPhrase(new Phrase("Quantity", font));
        table.addCell(cell);
         
        cell.setPhrase(new Phrase("Category", font));
        table.addCell(cell);  
        
        cell.setPhrase(new Phrase("Details", font));
        table.addCell(cell);  
    }
     
    private void writeTableData(PdfPTable table) {
        for (Apparel apparel : listApparel) {
            table.addCell(String.valueOf(apparel.getId()));
            table.addCell(apparel.getType());
            table.addCell(String.valueOf(apparel.getPrice()));
            table.addCell(String.valueOf(apparel.getQty()));
            table.addCell(String.valueOf(apparel.getCategory()));
            table.addCell(String.valueOf(apparel.getDetails()));
        }
    }
     
    public void export(HttpServletResponse response) throws DocumentException, IOException {
        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document, response.getOutputStream());
         
        document.open();
        Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
        font.setSize(18);
        font.setColor(Color.BLUE);
         
        Paragraph p = new Paragraph("List of Apparel Records", font);
        p.setAlignment(Paragraph.ALIGN_CENTER);
         
        document.add(p);
         
        PdfPTable table = new PdfPTable(6);
        table.setWidthPercentage(100f);
        table.setSpacingBefore(10);
         
        writeTableHeader(table);
        writeTableData(table);
         
        document.add(table);
         
        document.close();
         
    }
    
}