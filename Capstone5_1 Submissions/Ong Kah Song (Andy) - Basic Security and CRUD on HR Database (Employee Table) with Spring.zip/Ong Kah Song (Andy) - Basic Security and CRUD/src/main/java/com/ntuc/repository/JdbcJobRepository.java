package com.ntuc.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.ntuc.model.Job;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class JdbcJobRepository implements JobRepository {
	private JdbcTemplate jdbc;

	@Autowired
	public JdbcJobRepository(JdbcTemplate jdbc) {
		this.jdbc = jdbc;
	}

	@Override 
	public List<Job> findAll() {
		return jdbc.query("select * from jobs", this::mapRowToJob); 
	}

	private Job mapRowToJob(ResultSet rs, int rowNum) 
		throws SQLException {
		return new Job( 
				rs.getInt("job_id"), 
				rs.getString("job_title"), 
				rs.getBigDecimal("min_salary"), 
				rs.getBigDecimal("max_salary"));
	}
}
