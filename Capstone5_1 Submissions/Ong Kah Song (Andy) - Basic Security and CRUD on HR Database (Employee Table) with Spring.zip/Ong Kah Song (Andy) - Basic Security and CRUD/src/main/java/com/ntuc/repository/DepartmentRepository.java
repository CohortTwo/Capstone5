package com.ntuc.repository;

import java.util.List;

import com.ntuc.model.Department;

public interface DepartmentRepository {
	List<Department> findAll();
}
