package com.ntuc.security.service;

import com.ntuc.security.model.AppRole;
import com.ntuc.security.model.AppUser;
import com.ntuc.security.model.AppUserDetails;
import com.ntuc.security.repository.AppRoleRepository;
import com.ntuc.security.repository.AppUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.Optional;
import java.util.Set;

@Component
public class AppUserDetailServiceImpl implements UserDetailsService {

    private UserRoleMapService userRoleMapService;

    @Autowired
    public AppUserDetailServiceImpl(UserRoleMapService userRoleMapService){
        this.userRoleMapService = userRoleMapService;
    }

    @Override
    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {

        AppUser appUser = userRoleMapService.getAppUserWithRolesByUserName(s);

        Optional.ofNullable(appUser).orElseThrow(() -> new UsernameNotFoundException("User Not Found"));

        return new AppUserDetails(appUser);
    }
}
