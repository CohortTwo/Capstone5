package com.psn;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;



public interface EmployeeRepository extends JpaRepository<Employee,Long>{
	
	
	@Query("SELECT e FROM Employee e WHERE "
			+ " CONCAT(e.id, e.name, e.department, e.salary)" 
			+  " LIKE %?1%" )
	public Page<Employee> findAll(String keyword,Pageable pageable);
	

}
