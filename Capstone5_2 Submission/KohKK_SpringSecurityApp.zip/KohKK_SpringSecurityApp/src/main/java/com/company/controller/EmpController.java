package com.company.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.company.model.Department;
import com.company.model.Employee;
import com.company.repository.DepartmentRepository;
import com.company.repository.EmployeeRepository;
import com.company.service.EmployeePdfExporter;
import com.company.service.EmployeeService;
import com.lowagie.text.DocumentException;

@Controller
public class EmpController {
	@Autowired
	private EmployeeService service;
	@Autowired
	private DepartmentRepository depService;
	@Autowired
	private EmployeeRepository empRepo;

	@GetMapping("/employees")
	public String viewHomePage(Model model) {
		String keyword = null;
		return listByPage(model, 1, "name", "asc", keyword); // (HtmlPage, PageNumber, ColumnName, OrderDirection,
															// SearchKey)
	}

	@GetMapping("employees/page/{pageNumber}")
	public String listByPage(Model model, @PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField, @Param("sortDir") String sortDir, @Param("keyword") String keyword) {
		Page<Employee> page = service.listAll(currentPage, sortField, sortDir, keyword);
		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Employee> listEmployees = page.getContent();

		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listEmployees", listEmployees);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);

		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir", reverseSortDir);
		return "employeesHtml";
	}

	@GetMapping("employees/new")
	public String showNewEmployeeForm(Model model) {
		List<Department> listDeps = depService.findAll(); // added
		model.addAttribute("listDepartments", listDeps); // added
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		return "newEmployeeHtml"; // newEmployeeHtml
	}
	
	@PostMapping("/employees/checknew")
	public String checkEmployeeNew(@Valid Employee employee, BindingResult bindingResult, Model model, HttpServletRequest request) {
		if (bindingResult.hasErrors()) {
			List<Department> listDeps = depService.findAll(); // added
			model.addAttribute("listDepartments", listDeps); // added
			model.addAttribute("employee", employee);
			String[] detailIDs = request.getParameterValues("detailID");
			String[] detailNames = request.getParameterValues("detailName");
			String[] detailValues = request.getParameterValues("detailValue");
			model.addAttribute("detailID", detailIDs);
			model.addAttribute("detailName", detailNames);
			model.addAttribute("detailValue", detailValues);

			return "newEmployeeHtml";
		}

		return saveEmployee(employee, request);
	}
	
	@PostMapping("/employees/checkedit")
	public String checkEmployeeEdit(@Valid Employee employee, BindingResult bindingResult, HttpServletRequest request) {
		if (bindingResult.hasErrors()) {
			
			return "editEmployeeHtml";
		}
		return saveEmployee(employee, request);
	}
	

	@PostMapping("/employees/save")
	public String saveEmployee(Employee employee, HttpServletRequest request) {
		String[] detailIDs = request.getParameterValues("detailID");
		String[] detailNames = request.getParameterValues("detailName");
		String[] detailValues = request.getParameterValues("detailValue");
		for (int i = 0; i < detailNames.length; i++) {
			if (detailIDs != null && detailIDs.length > 0)
				employee.setDetails(Integer.valueOf(detailIDs[i]), detailNames[i], detailValues[i]);
			else {
				employee.addDetail(detailNames[i], detailValues[i]);
			}
		}
		service.save(employee);
		return "redirect:/employees";
	}

	@RequestMapping("employees/edit/{empid}")
	public ModelAndView showEditEmployeeForm(@PathVariable(name = "empid") Integer empid) {
		ModelAndView mav = new ModelAndView("editEmployeeHtml");
		Employee employee = service.get(empid);
		mav.addObject("employee", employee);
		return mav;
	}

	@RequestMapping("employees/delete/{id}")
	public String deleteEmployee(@PathVariable(name = "id") Integer id) {
		service.delete(id);
		return "redirect:/employees";
	}
	
	@GetMapping("/employees/exportCsv")
    public void exportToCSV(HttpServletResponse response) throws IOException {
        response.setContentType("text/csv");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        String currentDateTime = dateFormatter.format(new Date());
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
        response.setHeader(headerKey, headerValue);
        List<Employee> listEmployees = empRepo.findAll();
 
        ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
        String[] csvHeader = {"Employee ID", "Name", "Salary", "Department"};
        String[] nameMapping = {"empid", "name", "salary", "depid"};
         
        csvWriter.writeHeader(csvHeader);
         
        for (Employee employee : listEmployees) {
            csvWriter.write(employee, nameMapping);
        }
        csvWriter.close();
    }
	
	@GetMapping("/employees/exportPdf")
    public void exportToPDF(HttpServletResponse response) throws DocumentException, IOException {
        response.setContentType("application/pdf");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
        response.setHeader(headerKey, headerValue);
         
        List<Employee> listEmployees = empRepo.findAll();
         
       EmployeePdfExporter exporter = new EmployeePdfExporter(listEmployees);
       exporter.export(response);
    }
}
