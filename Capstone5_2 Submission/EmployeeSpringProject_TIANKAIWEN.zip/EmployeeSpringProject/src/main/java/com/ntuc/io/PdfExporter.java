package com.ntuc.io;

import java.util.Collection;

public class PdfExporter implements Exportable<Collection<?>,String> {


    @Override
    public String export(Collection<?> objects) {

        return null;
    }
}
