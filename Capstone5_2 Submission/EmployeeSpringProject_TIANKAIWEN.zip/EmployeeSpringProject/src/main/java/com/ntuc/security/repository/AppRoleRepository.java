package com.ntuc.security.repository;

import com.ntuc.security.model.AppRole;
import com.ntuc.security.model.AppUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Set;

public interface AppRoleRepository extends JpaRepository<AppRole,Long> {

//    @Query(value = "select ar from AppRole ar where ar.appUsers in :appUser")
    Set<AppRole> getAppRolesByAppUsers(/*@Param("appUser")*/ AppUser appUser);
}
