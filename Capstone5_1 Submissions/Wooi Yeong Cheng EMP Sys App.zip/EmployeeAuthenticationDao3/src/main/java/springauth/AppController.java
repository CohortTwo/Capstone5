package springauth;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import springauth.model.Dept;
import springauth.model.Emp;
import springauth.service.DeptService;
import springauth.service.EmpService;

@Controller
public class AppController {
	@Autowired
	private EmpService service;
	@Autowired
	private DeptService dservice;
	
	@RequestMapping("/")
	public String viewHomePage(Model model) {
		String keyword = null;
		return listByPage(model,1, "name", "asc",keyword);
	}
	
	
	@GetMapping("/page/{pageNumber}")
	public String listByPage(Model model,@PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField,
			@Param("sortDir") String sortDir,
			@Param("keyword") String keyword)	{
		
		Page<Dept> pagee = dservice.listAll(currentPage,sortField,sortDir,keyword);
		Integer totalItem = (int) pagee.getTotalElements();
		int totalPage = pagee.getTotalPages();
		List<Dept> listDepts = pagee.getContent();
		
		Page<Emp> page = service.listAll(currentPage,sortField,sortDir,keyword);
		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Emp> listEmps = page.getContent();
		
		model.addAttribute("totalPage", totalPage);
		model.addAttribute("totalItem", totalItem);
		model.addAttribute("listDepts", listDepts);
		
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listEmps", listEmps);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);
		
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir",reverseSortDir);
		return "index";
	}
	
	/*
	@GetMapping("/page/{pageNumber}")
	public String listByPage(Model model,@PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField,
			@Param("sortDir") String sortDir,
			@Param("keyword") String keyword)	{
		Page<Dept> page = dservice.listAll(currentPage,sortField,sortDir,keyword);
		Integer totalItems = (int) page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Dept> listDepts = page.getContent();
		
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listDepts", listDepts);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);
		
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir",reverseSortDir);
		return "index";
	}
	*/
	
	@RequestMapping("/newDept")
	public String showNewDeptForm(Model model) {
		Dept dept = new Dept();
		model.addAttribute("dept", dept);
		
		return "new_dept";
	}
	@RequestMapping(value = "/newDept/save", method = RequestMethod.POST)
	public String saveDept(@ModelAttribute("dept") Dept dept) {
		dservice.save(dept);
		
		return "redirect:/";
	}
	
	@RequestMapping("/newDept/edit/{id}")
	public ModelAndView showEditDeptForm(@PathVariable(name = "id") Integer id) {
		ModelAndView mav = new ModelAndView("edit_dept");
		
		Dept dept = dservice.get(id);
		mav.addObject("dept", dept);
		
		return mav;
	}	
	
	@RequestMapping("/newDept/delete/{id}")
	public String deleteDept(@PathVariable(name = "id") Integer id) {
		dservice.delete(id);
		
		return "redirect:/";
	}
	
	
	
	@RequestMapping("/newEmp")
	public String showNewEmpForm(Model model) {
		Emp emp = new Emp();
		model.addAttribute("emp", emp);
		
		return "new_emp";
	}
	
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveEmp(@ModelAttribute("emp") Emp emp) {
		service.save(emp);
		
		return "redirect:/";
	}
	
	@RequestMapping("/edit/{id}")
	public ModelAndView showEditEmpForm(@PathVariable(name = "id") Long id) {
		ModelAndView mav = new ModelAndView("edit_emp");
		
		Emp emp = service.get(id);
		mav.addObject("emp", emp);
		
		return mav;
	}	
	
	@RequestMapping("/delete/{id}")
	public String deleteEmp(@PathVariable(name = "id") Long id) {
		service.delete(id);
		
		return "redirect:/";
	}
}
