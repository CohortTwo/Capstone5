package com.company.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.company.model.Department;
import com.company.repository.DepartmentRepository;
import com.company.service.DepartmentPdfExporter;
import com.company.service.DepartmentService;
import com.lowagie.text.DocumentException;

@Controller
public class DepController implements WebMvcConfigurer {
	@Autowired
	private DepartmentService depService;
	
	@Autowired
	private DepartmentRepository depRepo;
	
	
//	@RequestMapping("/departments")
	@GetMapping("/departments")
	public String viewHomePage(Model model) {
		String keyword = null;
		return listByPage(model,1, "depname", "asc",keyword);	// (HtmlPage, PageNumber, ColumnName, OrderDirection, SearchKey)
	}
	
	@GetMapping("departments/page/{pageNumber}")
	public String listByPage(Model model,@PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField,
			@Param("sortDir") String sortDir,
			@Param("keyword") String keyword)	{
		Page<Department> page = depService.listAll(currentPage,sortField,sortDir,keyword);

		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Department> listDepartments = page.getContent();
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listDepartments", listDepartments);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir",reverseSortDir);
		return "departmentsHtml";
	}
	
//	@RequestMapping("departments/new")
	@GetMapping("departments/new")
	public String showNewDepartmentForm(Model model) {
		Department department = new Department();
		model.addAttribute("department", department);
		return "newDepartmentHtml";	
	}
	
	
	
	@PostMapping("/departments/checknew")
	public String checkDepartmentNew(@Valid Department department, BindingResult bindingResult, Model model) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("department", department);
			return "newDepartmentHtml";
		}
		return saveDepartment(department);
	}
	
	@PostMapping("/departments/checkedit")
	public String checkDepartmentEdit(@Valid Department department, BindingResult bindingResult, Model model) {
		if (bindingResult.hasErrors()) {
			model.addAttribute("department", department);
			var id=department.getDepid();
			return "editDepartmentHtml";
		}
		return saveDepartment(department);
	}
	
	@RequestMapping(value = "/departments/save", method = RequestMethod.POST)
	public String saveDepartment(@ModelAttribute("department") Department department) {
		depService.save(department);
		return "redirect:/departments";
	}
	
	@GetMapping("departments/edit/{id}")
	public ModelAndView showEditDepartmentForm(@PathVariable(name = "id") Integer id) {
		ModelAndView mav = new ModelAndView("editDepartmentHtml");
		Department department = depService.get(id);
		mav.addObject("department", department);
		return mav;
	}	
	
	@RequestMapping("departments/delete/{id}")
	public String deleteDepartment(@PathVariable(name = "id") Integer id) {
		depService.delete(id);
		return "redirect:/departments";
	}
	
	@GetMapping("/departments/exportCsv")
    public void exportToCSV(HttpServletResponse response) throws IOException {
        response.setContentType("text/csv");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        String currentDateTime = dateFormatter.format(new Date());
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
        response.setHeader(headerKey, headerValue);
        List<Department> listDepartments = depRepo.findAll();
 
        ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
        String[] csvHeader = {"Department ID", "Name"};
        String[] nameMapping = {"depid", "depname"};
        csvWriter.writeHeader(csvHeader);
         
        for (Department department : listDepartments) {
            csvWriter.write(department, nameMapping);
        }
        csvWriter.close();
    }

	@GetMapping("/departments/exportPdf")
    public void exportToPDF(HttpServletResponse response) throws DocumentException, IOException {
        response.setContentType("application/pdf");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
        response.setHeader(headerKey, headerValue);
        List<Department> listDepartments = depRepo.findAll();
         
       DepartmentPdfExporter exporter = new DepartmentPdfExporter(listDepartments);
       exporter.export(response);
    }
}
