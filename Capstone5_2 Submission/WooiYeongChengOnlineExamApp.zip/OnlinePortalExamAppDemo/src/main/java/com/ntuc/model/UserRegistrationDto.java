package com.ntuc.model;

public class UserRegistrationDto {

}
