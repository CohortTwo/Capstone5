package com.ntuc.io;

import java.util.Collection;

public interface CollectionExportable<T,U> extends Exportable<Collection<T>, U> {
}
