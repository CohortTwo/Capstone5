package com.demo.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.demo.model.Employee;

public interface EmployeeRepo extends JpaRepository<Employee, Integer> {

	@Query("SELECT e FROM Employee e WHERE "
		 + " lower(CONCAT(e.empid, e.empname, e.salary, e.department.deptname))"
		 + " LIKE lower(concat('%', ?1, '%'))"	)
	public Page<Employee> findAll(String keyword, Pageable pageable);
}
