package com.demo.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.demo.model.User;
import com.demo.model.UserPDFExporter;
import com.demo.model.UserRole;
import com.demo.repository.RoleRepo;
import com.demo.repository.UserRepo;
import com.lowagie.text.DocumentException;

@Controller
public class UserController {

	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private RoleRepo roleRepo;
	
	@RequestMapping("/user")
	public String showUsersList(Model model) {
		List<User> listUsers = userRepo.findAll();
		model.addAttribute("listUsers", listUsers);
		return "user";
	}
	
	@GetMapping("/user/new")
	public String showUserForm(Model model) {
		List<UserRole> roles = roleRepo.findAll();
		model.addAttribute("roles", roles);
		model.addAttribute("User", new User());
		return "user_form";
	}
	
	@PostMapping("/user/save")
	public String saveUser(User user) {
		userRepo.save(user);
		return "redirect:/user";
	}
	
	@GetMapping("/user/edit/{id}")
	public String showEditForm(@PathVariable("id") Long id, Model model) {
		User user = userRepo.findById(id).get();
		model.addAttribute("user", user);
		
		List<UserRole> roles = roleRepo.findAll();
		model.addAttribute("roles", roles);
		return "user_form";
	}
	
	@GetMapping("/user/delete/{id}")
	public String deleteUser(@PathVariable("id") Long id, Model model) {
		userRepo.deleteById(id);
		return "redirect:/users";
	}
	
	@GetMapping("/users/export/pdf")
    public void exportToPDF(HttpServletResponse response) throws DocumentException, IOException {
        response.setContentType("application/pdf");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());
         
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
        response.setHeader(headerKey, headerValue);
         
        List<User> listUsers = userRepo.findAll();
         
       UserPDFExporter exporter = new UserPDFExporter(listUsers);
       exporter.export(response);
    }
	
	@GetMapping("/users/export")
    public void exportToCSV(HttpServletResponse response) throws IOException {
        response.setContentType("text/csv");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        String currentDateTime = dateFormatter.format(new Date());
         
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
        response.setHeader(headerKey, headerValue);
         
        List<User> listUsers = userRepo.findAll();
 
        ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
        String[] csvHeader = {"User ID", "Username", "Password", "Roles", "Enabled"};
        String[] nameMapping = {"id", "username", "password", "roles", "enabled"};
         
        csvWriter.writeHeader(csvHeader);
         
        for (User user : listUsers) {
            csvWriter.write(user, nameMapping);
        }
         
        csvWriter.close();
         
    }
}
