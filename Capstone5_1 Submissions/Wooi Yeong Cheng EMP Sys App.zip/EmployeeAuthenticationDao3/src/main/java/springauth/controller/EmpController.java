package springauth.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import springauth.model.Dept;
import springauth.model.Emp;
import springauth.repository.DeptRepository;
import springauth.repository.EmpRepository;

@Controller
public class EmpController {

	@Autowired
	private EmpRepository repo;
	
	@Autowired
	private DeptRepository catrepo;
	
	
	@GetMapping("/emps")
	public String listEmps(Model model) {
		List<Emp> listEmps = repo.findAll();
		model.addAttribute("listEmps",listEmps);
		return "emps";
	}
	
	@GetMapping("/emps/new")
	public String showNewEmpForm(Model model) {
		List<Dept> listDepts =  catrepo.findAll();
		model.addAttribute("emp", new Emp());
		model.addAttribute("listDepts",listDepts);
		return "emp_form";
		
	}
	@PostMapping("/emps/save")
	public String saveEmp(Emp emp, HttpServletRequest request) {
		
		repo.save(emp);
		return "redirect:/emps";
	}

	
	@GetMapping("/emps/edit/{id}")
	public String ShowEmpEditForm(@PathVariable("id") Long id, Model model) {
		Emp emp = repo.findById(id).get();
		model.addAttribute("emp", emp);
		List<Dept> listDepts = catrepo.findAll();
		model.addAttribute("listDepts", listDepts);
		return "emp_form";
		
	}
	
	@GetMapping("/emps/delete/{id}")
	public String ShowEmpDeleteForm(@PathVariable("id") Long id, Model model) {
		repo.deleteById(id);
		return "redirect:/emps";
	}
	
	
	
}
