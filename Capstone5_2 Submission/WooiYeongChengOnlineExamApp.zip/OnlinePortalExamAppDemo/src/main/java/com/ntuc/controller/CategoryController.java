package com.ntuc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.ntuc.model.Category;
import com.ntuc.model.Product;
import com.ntuc.repository.CategoryRepository;
import com.ntuc.repository.ProductRepository;

@Controller
public class CategoryController {
	
	@Autowired
	private CategoryRepository catrepo;
	
	@Autowired
	private ProductRepository productrepo;
	
	@GetMapping("/categories")
	public String listCategories(Model model) {
		List<Category> listcategories = catrepo.findAll();
		model.addAttribute("listcategories",listcategories);
		return "categories";
	}
	
	@GetMapping("/categories/new")
	public String showNewCategoryForm(Model model) {
		model.addAttribute("category", new Category());
		return "category_form";
	}
	
	@PostMapping("/categories/save")
	public String saveCategoryForm(Category category) {
		catrepo.save(category);
		return "redirect:/categories";
	}
	
	@GetMapping("/categories/delete/{id}")
	public String deleteCategory(@PathVariable("id") Integer id, Model model) {
		catrepo.deleteById(id);
		return "redirect:/categories";
	}
	@GetMapping("/categories/edit/{id}")
	public String showEditCategoryForm(@PathVariable("id") Integer id, Model model) {
		Category category = catrepo.findById(id).get();
		model.addAttribute("category", category);
		List<Product>listProduct = productrepo.findAll();
		model.addAttribute("listProduct",listProduct);
		return "category_form";
	}
	
}
