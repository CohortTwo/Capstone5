package com.demo.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.demo.model.Department;
import com.demo.model.Employee;
import com.demo.repository.DepartmentRepo;
import com.demo.repository.EmployeeRepo;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeRepo emprepo;
	
	@Autowired
	private DepartmentRepo deptrepo;
	
	@GetMapping("/employees")
	public String listEmployees(Model model) {
		List<Employee> listEmployees = emprepo.findAll();
		model.addAttribute("listEmployees", listEmployees);
		return "employees";
	}
	
	@GetMapping("/employees/new")
	public String showNewEmployeeForm (Model model) {
		List<Department> listDepartments = deptrepo.findAll();
		model.addAttribute("employee", new Employee());
		model.addAttribute("listDepartments", listDepartments);
		return "employee_form";
	}
	
	@PostMapping("/employees/save")
	public String saveEmployee(Employee employee, HttpServletRequest request) {
		String [] detailIDs = request.getParameterValues("details");
		String [] detailRanks = request.getParameterValues("detailRank");
		String [] detailRoles = request.getParameterValues("detailRole");
		
		for (int i = 0; i < detailRanks.length; i++) {
			if(detailIDs != null && detailIDs.length > 0)
				employee.setDetails(Integer.valueOf(detailIDs[i]), detailRanks[i], detailRoles[i]);
			else {
				employee.addDetail(detailRanks[i], detailRoles[i]);
			}
		} 
		emprepo.save(employee);
		return "redirect:/";
	}
	
	@GetMapping("/employees/edit/{id}")
	public String showEmployeeEditForm(@PathVariable("id") Integer id, Model model) {
		Employee employee = emprepo.findById(id).get();
		model.addAttribute("employee", employee);
		List<Department> listDepartments = deptrepo.findAll();
		model.addAttribute("listDepartments", listDepartments);
		return "employee_form";
	}
	
	@GetMapping("/employees/delete/{id}")
	public String showEmployeeDeleteForm(@PathVariable("id") Integer id, Model model) {
		emprepo.deleteById(id);
		return "redirect:/";
	}
	
	
}
