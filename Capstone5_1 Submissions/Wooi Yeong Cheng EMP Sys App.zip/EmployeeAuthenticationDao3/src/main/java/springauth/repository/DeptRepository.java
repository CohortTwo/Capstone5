package springauth.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import springauth.model.Dept;

public interface DeptRepository extends JpaRepository<Dept, Integer> {

	@Query("SELECT d FROM Dept d WHERE "
			+ " CONCAT(d.id, d.name)" 
			+  " LIKE %?1%" )
	public Page<Dept> findAll(String keyword,Pageable pageable);
	
}
