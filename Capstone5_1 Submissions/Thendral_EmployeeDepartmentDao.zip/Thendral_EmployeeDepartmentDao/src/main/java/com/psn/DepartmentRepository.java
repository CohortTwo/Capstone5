package com.psn;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface DepartmentRepository extends JpaRepository<Department,Long> {
	
	@Query("SELECT d FROM Department d WHERE "
			+ " CONCAT(d.id, d.name)" 
			+  " LIKE %?1%" )
	public Page<Department> findAll(String keyword,Pageable pageable);
	

}
