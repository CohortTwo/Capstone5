package com.ntuc.repository;

import com.ntuc.model.Employee;
import com.ntuc.model.EmployeeDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeDetailsRepository extends JpaRepository<EmployeeDetails,Long> {

    @Query("select ed from EmployeeDetails ed where ed.employee.empId in :emp")
    List<EmployeeDetails> findEmployeeDetailsFromEmployee(@Param("emp") List<Long> employeeList);
}
