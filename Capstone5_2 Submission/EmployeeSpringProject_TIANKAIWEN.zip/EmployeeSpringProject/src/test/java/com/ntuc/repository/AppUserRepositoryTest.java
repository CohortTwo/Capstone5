package com.ntuc.repository;

import com.ntuc.security.model.AppRole;
import com.ntuc.security.model.AppUser;
import com.ntuc.security.repository.AppUserRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.EmbeddedDatabaseConnection;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@ExtendWith(SpringExtension.class)
@DataJpaTest
@AutoConfigureTestDatabase(connection = EmbeddedDatabaseConnection.H2)
@Rollback
class AppUserRepositoryTest {

    @Autowired
    private AppUserRepository appUserRepository;

    @Test
    public void createNewAppUser(){
        Set<AppRole> appRoles = new HashSet<>();
        AppRole role1 = new AppRole(1L,"ROLE1");
        AppRole role2 = new AppRole(2L,"ROLE2");
        appRoles.add(role1);
        appRoles.add(role2);
        AppUser appUser = new AppUser(1L,appRoles,"tom","tom",
                true,false, LocalDate.now().plusDays(50),LocalDate.now().plusDays(50));
        role1.addAppUser(appUser);
        role2.addAppUser(appUser);
        AppUser savedUser = appUserRepository.save(appUser);
        Assertions.assertTrue(savedUser.getAppUserId()>0);
    }


}