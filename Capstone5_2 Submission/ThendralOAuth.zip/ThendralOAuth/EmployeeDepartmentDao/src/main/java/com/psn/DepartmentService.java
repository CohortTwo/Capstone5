package com.psn;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
public class DepartmentService {
	@Autowired
	private DepartmentRepository deptrepo;
	public Page<Department> listAll(int pageNumber, String sortField, String sortDir, String keyword){
		Sort sort = Sort.by(sortField);
		sort = sortDir.equals("asc") ? sort.ascending() : sort.descending();
		Pageable pageable = PageRequest.of(pageNumber-1, 5,sort);
		if(keyword!=null) {
		return deptrepo.findAll(keyword,pageable);
		}
		return deptrepo.findAll(pageable);
			
	}
	
	public void save(Department department) {
		deptrepo.save(department);
	}
	
	public Department get(Long id) {
		return deptrepo.findById(id).get();
	}
	
	public void delete(Long id) {
		deptrepo.deleteById(id);
	}
}
