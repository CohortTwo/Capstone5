package com.ntuc.repository;

import com.ntuc.model.Employee;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee,Long> {

    @Query("SELECT e FROM Employee e WHERE "
            + " CONCAT(e.empId,e.name)"
            +  " LIKE %?1%" )
    Page<Employee> findAll(String keyword, Pageable pageable);

    List<Employee> findAllByNameContaining(String keyword);
}
