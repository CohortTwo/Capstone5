package springbeanscope;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBeanScope {

	public static void main(String[] args) {
		SpringApplication.run(SpringBeanScope.class, args);
	}

}

/*singleton (Default Scope)
 * prototype 
 * request 
 * session 
 * application 
 * websocket
 * */
