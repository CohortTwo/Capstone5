package com.company.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.company.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	@Query("SELECT e FROM Employee e join Department d on e.depid=d.depid WHERE CONCAT(e.empid, e.name, e.salary, d.depname) LIKE %?1%")

//	@Query(value="select e from employee e Where CONCAT(e.empid, e.name, e.salary) LIKE %?1%", nativeQuery=true)
	
//	@Query("SELECT e FROM Employee e join Department d on e.depid=d.depid WHERE CONCAT(e.empid, e.name, e.salary, d.depname) LIKE %?1%")
	
	public Page<Employee> findAll(String keyword, Pageable pageable);
}
