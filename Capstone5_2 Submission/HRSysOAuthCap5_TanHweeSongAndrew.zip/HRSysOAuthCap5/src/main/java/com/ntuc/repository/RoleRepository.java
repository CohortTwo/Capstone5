package com.ntuc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ntuc.model.UserRole;

public interface RoleRepository extends JpaRepository<UserRole, Integer>{
	
	

}
