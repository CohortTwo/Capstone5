package com.hresource.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import com.hresource.repository.DepartmentRepository;
import com.hresource.service.EmployeeService;

@Controller
public class FormController {
	@Autowired
	private EmployeeService service;
	
	@Autowired
	private DepartmentRepository catrepo;
}
