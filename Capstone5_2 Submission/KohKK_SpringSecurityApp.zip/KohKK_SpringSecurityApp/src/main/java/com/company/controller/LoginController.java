package com.company.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {
	@GetMapping("/login")	// endpoint, http://localhost:8080/login
	public String showLogin() {
	return "loginHtml";
	}
	
	@GetMapping("/login-error")	// endpoint, http://localhost:8080/login-error
	public String loginerror() {
	return "loginErrorHtml";
	}
}
