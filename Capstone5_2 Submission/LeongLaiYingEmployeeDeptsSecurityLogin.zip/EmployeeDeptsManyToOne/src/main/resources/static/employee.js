var contacts=[];
function addContacts(e){
	
	// var urel = document.getElementById("contact_details");
 	var urel = document.getElementById("toDoList");
	var li = document.createElement("tr");

// ID
	var td1 = document.createElement("td");
	td1.classList = "column1";
	var txtID = document.createElement("input");
	txtID.type = "text";
	txtID.value = "0";
	txtID.name = "contactID";
	txtID.readOnly = true;
	td1.appendChild(txtID);
// Contact	
	var td2 = document.createElement("td");
	td2.classList = "column2";
	
	var txt = document.createElement("input");
	txt.type = "text";
	txt.name = "contact";
	txt.placeholder= "contact";
	txt.step = "0.1";
	//txt.className="form-control";
	txt.required = true;
	
	td2.appendChild(txt);


// Delete
	var td3 = document.createElement("td");
	td3.classList = "column3";
        //  *********************Add the delete  to each Li ***************************
        var deleteButton = document.createElement("button");
        var xString = document.createTextNode("X");
        deleteButton.appendChild(xString);

       deleteButton.className = "btn btn-primary";
        deleteButton.classList = "deleteButton";
        deleteButton.addEventListener("click", function (e) {
			
        })
        td3.appendChild(deleteButton);
			// li.className="col-sm-4";
	 li.appendChild(td1);
	 li.appendChild(td2);
	 li.appendChild(td3);
	 urel.appendChild(li);
}

function loadContact(){
//	var contacts =$('#listcontact').val();
//	var contacts =/*[[${listContacts}]]*/ [];
	var contacts = document.getElementById("listContacts");
    var urel = document.getElementById("toDoList");
  console.log('here'+contacts.id);
//console.log(contacts[0].contact);
    urel.innerHTML = "";
    for (let i = 0; i < contacts.length; i++) {
        //   &&&&& Create 1 task
        var li = document.createElement("tr");

//----
// ID
	var td1 = document.createElement("td");
	td1.classList = "column1";
	var txtID = document.createElement("input");
	txtID.textContent = contacts[i].id;
	txtID.Text=contacts[i].id;
	txtID.type = "text";
	txtID.name = "ID";
	txtID.readOnly = true;
	td1.appendChild(txtID);
	
	// Contact	
	var td2 = document.createElement("td");
	td2.classList = "column2";
	
	var txt = document.createElement("input");
	txt.textContent = contacts[i].contact;
	txt.TEXT_NODE = contacts[i].contact;
	txt.Text=contacts[i].contact;
	txt.type = "text";
	txt.name = "contact";
	txt.placeholder= "contact";
	txt.step = "0.1";
	txt.required = true;
	
	td2.appendChild(txt);


// Delete
	var td3 = document.createElement("td");
	td3.classList = "column3";
        //  *********************Add the delete  to each Li ***************************
        var deleteButton = document.createElement("button");
        var xString = document.createTextNode("X");
        deleteButton.appendChild(xString);
        deleteButton.className = "btn btn-primary";
        deleteButton.classList = "deleteButton";
        deleteButton.addEventListener("click", function (e) {
			
        })
        td3.appendChild(deleteButton);
			// li.className="col-sm-4";
	 li.appendChild(td1);
	 li.appendChild(td2);
	 li.appendChild(td3);
	 urel.appendChild(li);
     //   if(document.getElementById)

        document.getElementById("toDoList").appendChild(li);
    }
}
	