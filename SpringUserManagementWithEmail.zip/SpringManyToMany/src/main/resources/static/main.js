/**
 * 
 */

    $('#deleteModal').on('show.bs.modal', function () {
	
	$('table #deleteButton').on('click',function(event){
		event.preventdefault();
		var href=$(this).attr('href');
		$('#deleteModal #delRef').attr('href',href);
		$('#deleteModal').modal();
	});

	});
