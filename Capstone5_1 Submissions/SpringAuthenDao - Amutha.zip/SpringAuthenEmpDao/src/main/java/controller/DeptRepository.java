package controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface DeptRepository extends JpaRepository<Dept, Integer> {

	
//	@Query("SELECT p FROM Product p WHERE p.name LIKE %?1%"
//			+ " OR p.brand LIKE %?1%"
//			+ " OR p.madein LIKE %?1%")
//	public List<Product> findAll(String keyword);
	
	@Query("SELECT p FROM Dept p WHERE "
			+ " CONCAT(p.deptno, p.dname, p.loc)" 
			+  " LIKE %?1%" )
	public Page<Dept> findAll(String keyword,Pageable pageable);
	
}
