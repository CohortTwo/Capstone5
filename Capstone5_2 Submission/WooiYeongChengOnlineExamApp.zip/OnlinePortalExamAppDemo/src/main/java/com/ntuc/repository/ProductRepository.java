package com.ntuc.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ntuc.model.Product;


public interface ProductRepository extends JpaRepository<Product, Integer> {

	@Query("SELECT a FROM Product a WHERE "
			+ " CONCAT(a.id, a.category.name, a.price, a.name)" 
			+  " LIKE %?1%" )
	public Page<Product> findAll(String keyword,Pageable pageable);
	
}
