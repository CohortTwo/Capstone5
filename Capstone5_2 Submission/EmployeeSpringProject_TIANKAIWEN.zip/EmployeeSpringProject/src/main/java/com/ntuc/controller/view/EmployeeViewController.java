package com.ntuc.controller.view;

import com.ntuc.model.*;
import com.ntuc.repository.EmployeeDetailsRepository;
import com.ntuc.service.DepartmentService;
import com.ntuc.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class EmployeeViewController {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private DepartmentService departmentService;

    @Autowired
    private EmployeeDetailsRepository employeeDetailsRepository;

    @GetMapping("/emp/new")
    public String getCreateEmpPage(Model model){
        model.addAttribute("employee",new Employee());
        model.addAttribute("departmentList",departmentService.showDepartments());
        model.addAttribute("jobHistory", new JobHistory());
        model.addAttribute("contactDetails",new ContactDetails());
        return "emp/empnew";
    }


    @PostMapping("/emp/save")
    public String createEmp(Employee employee, JobHistory jobHistory, ContactDetails contactDetails){
        EmployeeDetails employeeDetails = new EmployeeDetails();
        employeeDetails.setContactDetails(contactDetails);
        employee.setEmployeeDetails(employeeDetails);
        employeeDetails.setEmployee(employee);
        employee.addJobHistory(jobHistory);
        employeeService.addEmployee(employee);
        return "index";
    }


    @GetMapping("/emp/view")
    public String viewEmp(Model model){
        List<Employee> employees = employeeService.showEmployees();
        Department department = employees.get(0).getDepartment();
        String name = department.getDeptName();
        model.addAttribute("empList", employees);
        return "emp/empview";
    }


    @GetMapping("/emp/view/page")
    public String viewDepartmentPageByPaging(Model model,
                                             @RequestParam("pageNo") Optional<Integer> pageNo,
                                             @RequestParam("dir")Optional<String> dir,
                                             @RequestParam("field")Optional<String> field,
                                             @RequestParam("keyword")Optional<String> keyword){
        int currentPage = pageNo.orElse(1);
        String direction = dir.orElse("asc");
        String fields = field.orElse("empId");
        String keywords = keyword.orElse("");
        String reverseDirection = direction.equalsIgnoreCase("asc") ? "desc" : "asc";
        Page<Employee> employeePage = employeeService.showEmployeesByPaging(currentPage,direction,fields,keywords);
        int totalPages = employeePage.getTotalPages();
        model.addAttribute("empPage", employeePage);
        model.addAttribute("totalElements",employeePage.getTotalElements());
        model.addAttribute("currentPage",currentPage);
        model.addAttribute("totalPages", totalPages);
        model.addAttribute("direction",direction);
        model.addAttribute("reverseDirection", reverseDirection);
        model.addAttribute("fields",fields);
        model.addAttribute("keywords",keywords);
        return "emp/empviewpaging";
    }


    @GetMapping("/emp/export/csv")
    public void exportEmployeeToCsv(@RequestParam("keyword")String keyword,
                                    HttpServletResponse response) throws IOException {
        final String fileName = "emp_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("ddMMyyyyHHmmss")) + ".csv";
        response.setContentType("text/csv");
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename=\"" + fileName + "\"");
        List<Employee> employees = employeeService.showDepartmentsByNameLike(keyword);
        employeeService.exportToCsv(response.getWriter(),employees);
    }


    @GetMapping("/emp/export/pdf")
    public void exportEmployeeToPdf(@RequestParam("keyword")String keyword,
                                    HttpServletResponse response) throws IOException {
        final String fileName = "emp_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("ddMMyyyyHHmmss")) + ".pdf";
        response.setContentType("application/pdf");
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename=\"" + fileName + "\"");
        List<Employee> employees = employeeService.showDepartmentsByNameLike(keyword);
        employeeService.exportToPdf(response.getOutputStream(),employees);

    }

}
