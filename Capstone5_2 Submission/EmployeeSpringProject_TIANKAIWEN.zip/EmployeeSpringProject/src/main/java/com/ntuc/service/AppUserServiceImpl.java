package com.ntuc.service;

import com.ntuc.security.model.AppUser;
import com.ntuc.security.repository.AppUserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AppUserServiceImpl implements AppUserService {

    @Autowired
    private AppUserRepository appUserRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public AppUser findAppUserByUsername(String username) {
        AppUser appUser = appUserRepository.findAppUserByUsername(username);
        return appUser;
    }

    @Override
    public boolean validatePassword(String password, String confirmPassword) {
        return password.equals(confirmPassword);
    }

    @Override
    public void updateAppUserWithNewPassword(AppUser user, String password){
        user.setPassword(passwordEncoder.encode(password));
        appUserRepository.save(user);
    }

    public void createAppUser(AppUser appUser){

    }
}
