package com.ntuc.io;

public interface Exportable<R,S> {

    S export(R r);

}
