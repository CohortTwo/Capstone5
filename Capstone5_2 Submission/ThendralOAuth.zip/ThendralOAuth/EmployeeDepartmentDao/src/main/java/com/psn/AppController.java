package com.psn;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.lowagie.text.DocumentException;


@Controller
public class AppController {
	
	@Autowired
	private EmployeeRepository repo;
	
	@Autowired
	private DepartmentRepository deptrepo;
	
	
	@Autowired
	private EmployeeService service;
	
	@Autowired
	private DepartmentService dservice;
	
	
	/* @GetMapping("/") public String goHome() { return "home"; } */
	 
	
	
	  @RequestMapping("/") 
	  public String viewHomePage(Model model) 
	  { 
		  String keyword = null; 
		  return listByPage(model,1, "name", "asc",keyword);
	  }
	  
	  @GetMapping("/login-error")
		public String loginerror() {
	         return "login-error";
		}
	  
	  @GetMapping("/login")	
		public String showLoginpage() {
			return "login";
		}
	  
	  @GetMapping("/home")	
		public String showHomepage() {
			return "home";
		}

	 
	@GetMapping("/page/{pageNumber}")
	public String listByPage(Model model,@PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField,
			@Param("sortDir") String sortDir,
			@Param("keyword") String keyword)	{
		Page<Employee> page = service.listAll(currentPage,sortField,sortDir,keyword);
		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Employee> listEmployees = page.getContent();
		
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listEmployees", listEmployees);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);
		
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir",reverseSortDir);
		return "index";
}
	
	

  @GetMapping("/pages/{pageNumber}") 
  public String listByPages(Model model,@PathVariable("pageNumber") int currentPage,
  
		  @Param("sortField") String sortField,  
		  @Param("sortDir") String sortDir,
		  @Param("keyword") String keyword) { 
	  Page<Department> pages= dservice.listAll(currentPage,sortField,sortDir,keyword);
	  Long totalItems = pages.getTotalElements(); 
	  int totalPages = pages.getTotalPages();
	  List<Department> listDepartments = pages.getContent();
  
  model.addAttribute("currentPage", currentPage);
  model.addAttribute("totalPages", totalPages);
  model.addAttribute("totalItems", totalItems);
  model.addAttribute("listDepartments", listDepartments);
  model.addAttribute("sortField", sortField); model.addAttribute("sortDir",sortDir);
  model.addAttribute("sortDir", sortDir);
  model.addAttribute("keyword", keyword);
  
  String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
  model.addAttribute("reverseSortDir",reverseSortDir);
  return "department";
  }
   
  
        	/* Mapping for Employees */
  
	
	@RequestMapping("/new")
	public String showNewEmployeeForm(Model model) {
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		
		return "new_employee";
	}
	
		
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveEmployee(@ModelAttribute("employee") Employee employee) {
		service.save(employee);
		return "redirect:/";
	}
	
	@RequestMapping("/edit/{id}")
	public ModelAndView showEditEmployeeForm(@PathVariable(name = "id") Long id) {
		ModelAndView mav = new ModelAndView("edit_Employee");
		Employee employee = service.get(id);
		mav.addObject("employee", employee);
		
		return mav;
	}	
	
	@RequestMapping("/delete/{id}")
	public String deleteEmployee(@PathVariable(name = "id") Long id) {
		service.delete(id);		
		return "redirect:/";
	}
	
	
       	/* Mapping for Department */
	
	@RequestMapping("/department")
	public String ShowDepartment(Model model){
			List<Department> listdepartments = deptrepo.findAll();
			model.addAttribute("listdepartments",listdepartments);
	 		return "department";
	}	
	
	@RequestMapping("/newdept")
	public String showNewDeptForm(Model model) {
		Department department = new Department();
		model.addAttribute("department", department);
		
		return "new_dept";
	}
	
	
	@RequestMapping(value = "/savedept", method = RequestMethod.POST)
	public String saveDepartment(@ModelAttribute("department") Department department) {
		dservice.save(department);
		return "redirect:/department";
	}
	
	
	@RequestMapping("/editdept/{id}")
	public ModelAndView showEditDepartmentForm(@PathVariable(name = "id") Long id) {
		ModelAndView mav = new ModelAndView("edit_dept");
		
		Department department = dservice.get(id);
		mav.addObject("department", department);
		
		return mav;
	}	
	
	
	@RequestMapping("/deletedept/{id}")
	public String deleteDepartment(@PathVariable(name = "id") Long id) {
		dservice.delete(id);
		
		return "redirect:/department";
	}
	
	/* Mapping for Export pdf and csv */
	
	@GetMapping("/employees/export/pdf")
    public void exportToPDF(HttpServletResponse response) throws DocumentException, IOException {
        response.setContentType("application/pdf");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());
         
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=employees_" + currentDateTime + ".pdf";
        response.setHeader(headerKey, headerValue);
         
        List<Employee> listEmployees = repo.findAll();
         
       EmployeePdfExport exporter = new EmployeePdfExport(listEmployees);
       exporter.export(response);
    }
	@GetMapping("/employees/export")
    public void exportToCSV(HttpServletResponse response) throws IOException {
        response.setContentType("text/csv");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        String currentDateTime = dateFormatter.format(new Date());
         
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=employees_" + currentDateTime + ".csv";
        response.setHeader(headerKey, headerValue);
         
        List<Employee> listEmployees = repo.findAll();
 
        ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
        String[] csvHeader = {"Employee ID", "Employee name", "Department", "Salary"};
        String[] nameMapping = {"id", "name", "department", "salary"};
         
        csvWriter.writeHeader(csvHeader);
         
        for (Employee employee : listEmployees) {
            csvWriter.write(employee, nameMapping);
        }
         
        csvWriter.close();
         
    }

	
}
