package com.company.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer empid;
	@Column(length = 150, nullable = false, unique=true)
	@Size(min=2, max=150)
	private String name;
	@Min(100)
	private Double salary;
	
	@ManyToOne	// many current class to one class field defined below.
	@JoinColumn(name= "depid")		// (=> column name on database table = "depid")
	private Department depid;

	@OneToMany(mappedBy ="empDetail", cascade = CascadeType.ALL)
	private List<EmployeeDetail> details = new ArrayList<>();
	
	public Employee() {

	}

	public Integer getEmpid() {
		return empid;
	}
	
	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
	
	public List<EmployeeDetail> getDetails() {
		return details;
	}

	public void setDetails(List<EmployeeDetail> details) {
		this.details = details;
	}
	
	public void setDetails(Integer id,String name, String value) {
		this.details.add(new EmployeeDetail(id,name,value,this)  );
		
	}

	public void addDetail(String name, String value) {
		this.details.add(new EmployeeDetail(name,value,this));
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public Double getSalary() {
		return salary;
	}
	
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public Department getDepid() {
		return depid;
	}
	
	public void setDepid(Department depid) {
		this.depid = depid;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", salary=" + salary + ", depid=" + depid + ", details="
				+ details + "]";
	}
}
