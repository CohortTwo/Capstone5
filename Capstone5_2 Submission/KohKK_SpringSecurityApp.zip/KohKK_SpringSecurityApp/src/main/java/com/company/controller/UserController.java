package com.company.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.company.model.Department;
import com.company.model.Users;
import com.company.repository.UserRepository;
import com.company.service.UserPdfExporter;
import com.company.service.UserService;
import com.lowagie.text.DocumentException;

@Controller
public class UserController {
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRepository userRepo;
	
	@RequestMapping("/users")
	public String viewHomePage(Model model) {
		String keyword = null;
		return listByPage(model,1, "username", "asc",keyword);	// (HtmlPage, PageNumber, ColumnName, OrderDirection, SearchKey)
	}
	
	@GetMapping("users/page/{pageNumber}")
	public String listByPage(Model model,@PathVariable("pageNumber") int currentPage,
		@Param("sortField") String sortField,
		@Param("sortDir") String sortDir,
		@Param("keyword") String keyword)	{
		Page<Users> page = userService.listAll(currentPage,sortField,sortDir,keyword);

		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<Users> listUsers = page.getContent();
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listUsers", listUsers);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);
		
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir",reverseSortDir);
		return "usersHtml";
	}
	
	
	@RequestMapping("users/new")
	public String showNewUserForm(Model model) {
		Users user = new Users();
		model.addAttribute("user", user);
		return "newUserHtml";	
	}
	
	@PostMapping("/users/checknew")
	public String checkUserNew(@Valid Users user, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			return "newUserHtml";
		}
		return saveUser(user);
	}
	
	@PostMapping("/users/checkedit")
	public String checkUserEdit(@Valid Users user, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			return "editUserHtml";
		}
		return saveUser(user);
	}
	
	
	
	
	@RequestMapping(value = "/users/save", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute("user") Users user) {
		userService.save(user);
		return "redirect:/users";
	}
	
	@RequestMapping("users/edit/{id}")
	public ModelAndView showEditUserForm(@PathVariable(name = "id") Integer id) {
		ModelAndView mav = new ModelAndView("editUserHtml");
		Users user = userService.get(id);
		mav.addObject("user", user);
		return mav;
	}	
	
	@RequestMapping("users/delete/{id}")
	public String deleteDepartment(@PathVariable(name = "id") Integer id) {
		userService.delete(id);
		return "redirect:/users";
	}
	
	@GetMapping("/users/exportCsv")
    public void exportToCSV(HttpServletResponse response) throws IOException {
        response.setContentType("text/csv");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        String currentDateTime = dateFormatter.format(new Date());
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
        response.setHeader(headerKey, headerValue);
         
        List<Users> listUsers = userRepo.findAll();
 
        ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
        String[] csvHeader = {"User ID", "Name", "Password", "Enabled"};
        String[] nameMapping = {"userid", "username", "password", "enabled"};
         
        csvWriter.writeHeader(csvHeader);
         
        for (Users user : listUsers) {
            csvWriter.write(user, nameMapping);
        }
        csvWriter.close();
    }

	@GetMapping("/users/exportPdf")
    public void exportToPDF(HttpServletResponse response) throws DocumentException, IOException {
        response.setContentType("application/pdf");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
        response.setHeader(headerKey, headerValue);
         
        List<Users> listUsers = userRepo.findAll();
         
        UserPdfExporter exporter = new UserPdfExporter(listUsers);
        exporter.export(response);
    }
}
