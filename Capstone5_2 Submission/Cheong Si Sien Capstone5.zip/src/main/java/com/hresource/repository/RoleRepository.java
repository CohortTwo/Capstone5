package com.hresource.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hresource.model.UserRole;

public interface RoleRepository extends JpaRepository<UserRole, Integer>{
}
