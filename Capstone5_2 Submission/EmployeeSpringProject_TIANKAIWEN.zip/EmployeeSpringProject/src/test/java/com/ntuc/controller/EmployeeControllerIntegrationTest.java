package com.ntuc.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EmployeeControllerIntegrationTest {

    @Test
    void showEmployees() {
    }

    @Test
    void getEmployeeUsingId() {
    }

    @Test
    void addEmployees() {
    }

    @Test
    void modifyEmployee() {
    }

    @Test
    void removeEmployee() {
    }
}