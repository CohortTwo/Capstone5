package com.ntuc.security;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lowagie.text.DocumentException;
import com.ntuc.repository.UserRoleRepository;
import com.ntuc.service.UserPDFExporter;
import com.ntuc.service.UserService;

import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

@Controller
public class UserController {

	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private UserRoleRepository urRepo;
	
	@Autowired
	private UserService service;
	
	@GetMapping("/login")
	public String loginPage() {
		return "login";
	}
	
	@GetMapping("login-error")
	public String loginError() {
		return "login-error";
	}
	
	@GetMapping("/logout")
	public String logoutPage() {
		return "logout_success";
	}
	
	@GetMapping("/")
    public String viewHomePage() {
        return "index";
	}
	
	@RequestMapping("/user")
	public String viewUserPage(Model model) {
		String keyword = null;
		return listByPage(model,1,"username","asc",keyword);
	}
	
	@GetMapping("/users/page/{pageNumber}")
	public String listByPage(Model model,@PathVariable("pageNumber") int currentPage,
			@Param("sortField") String sortField,
			@Param("sortDir") String sortDir,
			@Param("keyword") String keyword) {
		Page<User> page = service.listAll(currentPage,sortField,sortDir,keyword);
		//System.out.println(page);
		Long totalItems = page.getTotalElements();
		int totalPages = page.getTotalPages();
		List<User> listusers = page.getContent();
	
		model.addAttribute("currentPage", currentPage);
		model.addAttribute("totalPages", totalPages);
		model.addAttribute("totalItems", totalItems);
		model.addAttribute("listUsers", listusers);
		model.addAttribute("sortField", sortField);
		model.addAttribute("sortDir", sortDir);
		model.addAttribute("keyword", keyword);
		System.out.println("total pages = " + totalPages);
		String reverseSortDir = sortDir.equals("asc") ? "desc" : "asc";
		model.addAttribute("reverseSortDir",reverseSortDir);
		return "users";
	}
	
	@GetMapping("/register")
	public String showRegistrationForm(Model model) {
	    model.addAttribute("user", new User());
	    List<UserRole> roles=urRepo.findAll();
	    model.addAttribute("userRoles", roles);
	     
	    return "signup_form";
	}
	
	@PostMapping("/process_register")
	public String processRegister(User user, UserRole role) {
	    BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	    String encodedPassword = passwordEncoder.encode(user.getPassword());
	    user.setPassword(encodedPassword);
	    System.out.println("User :"+user.getFullName()+", Role: " + role.getName());
	//    urRepo.save(role);
	    userRepo.save(user);
	     
	    return "redirect:/users";
	}
	
	@GetMapping("/users")
	public String listUsers(Model model) {
	    List<User> listusers = (List<User>) userRepo.findAll();
	    List<UserRole> roles = urRepo.findAll();
	    model.addAttribute("listUsers", listusers);
	    model.addAttribute("userRoles", roles);
	     
	    return "users";
	}
	
	@GetMapping("/users/edit/{id}")
	public String UserEditForm(@PathVariable("id")Long id, Model model) {
		User user = userRepo.findById(id).get();
		model.addAttribute("user", user);
		List<UserRole> listUserRole = urRepo.findAll();
		model.addAttribute("userRoles", listUserRole);
		return "signup_form";	
	}
	
	@GetMapping("/users/delete/{id}")
	public String UserDeleteForm(@PathVariable("id") Long id, Model model) {
		userRepo.deleteById(id);
		return "redirect:/users";
	}
	
	@PostMapping("/users/save")
	public String saveUser(User user, UserRole role) {
		userRepo.save(user);
	//	urRepo.save(role);
		return "redirect:/users";
	}
	
	@RequestMapping("/main")
	public String main() {
	    return "main";
	}
	
	@RequestMapping("/index")
	public String index() {
	    return "index";
	}
	
	@GetMapping("/users/export/pdf")
	public void exportToPDF(HttpServletResponse response) throws DocumentException, IOException{
		response.setContentType("application/pdf");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());
         
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
        response.setHeader(headerKey, headerValue);
         
        List<User> listUsers = userRepo.findAll();
         
       UserPDFExporter exporter = new UserPDFExporter(listUsers);
       exporter.export(response);
				
	}
	
	@GetMapping("/users/export")
    public void exportToCSV(HttpServletResponse response) throws IOException {
        response.setContentType("text/csv");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        String currentDateTime = dateFormatter.format(new Date());
         
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
        response.setHeader(headerKey, headerValue);
         
        List<User> listUsers = userRepo.findAll();
 
        ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
        String[] csvHeader = {"User ID", "Username", "Password", "Roles", "Enabled"};
        String[] nameMapping = {"id", "username", "password", "roles", "enabled"};
         
        csvWriter.writeHeader(csvHeader);
         
        for (User user : listUsers) {
            csvWriter.write(user, nameMapping);
        }
         
        csvWriter.close();
         
    }
	
	
}
