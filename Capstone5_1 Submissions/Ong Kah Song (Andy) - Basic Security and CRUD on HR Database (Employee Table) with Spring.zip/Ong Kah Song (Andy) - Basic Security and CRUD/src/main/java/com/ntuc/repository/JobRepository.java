package com.ntuc.repository;

import java.util.List;

import com.ntuc.model.Job;

public interface JobRepository {
	List<Job> findAll();
}
