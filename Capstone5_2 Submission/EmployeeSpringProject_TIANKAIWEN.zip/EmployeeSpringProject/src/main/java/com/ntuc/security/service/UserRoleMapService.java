package com.ntuc.security.service;

import com.ntuc.security.model.AppUser;

public interface UserRoleMapService {
    AppUser getAppUserWithRolesByUserName(String userName);
}
