package com.ntuc.io;

import com.lowagie.text.*;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

import java.awt.*;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.util.Collection;

public class OpenPdfTableExporter<T> implements CollectionExportable<T,Void>{

    private final OutputStream os;
    private final Class<?> clazz;

    public OpenPdfTableExporter(OutputStream os, Class<?> clazz){
        this.os = os;
        this.clazz = clazz;
    }

    @Override
    public Void export(Collection<T> objects) {

        if(objects==null || objects.isEmpty()){
            return null;
        }

        Document document = new Document(PageSize.A4);
        PdfWriter.getInstance(document,os);

        document.open();
        Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
        font.setSize(18);
        font.setColor(Color.BLUE);

        Paragraph p = new Paragraph("List of " + clazz.getSimpleName(), font);
        p.setAlignment(Paragraph.ALIGN_CENTER);
        document.add(p);



        String[] arr = getFieldsFromCollection(objects);
        String[] header = convertCamelCaseToUpperCase(arr);

        PdfPTable table = new PdfPTable(arr.length);
        table.setWidthPercentage(100f);
        table.setSpacingBefore(10);

        writeTableHeader(table,header);
        writeTableData(table,objects,arr);

        document.add(table);

        document.close();

        return null;
    }

    private void writeTableData(PdfPTable table, Collection<?> objects, String[] fields) {
        Object[] arr = objects.toArray();
        for(int i = 0; i < arr.length ; i++){
            for(int j = 0; j < fields.length ; j++){
                try {
                    Field field = arr[i].getClass().getDeclaredField(fields[j]);
                    field.setAccessible(true);
                    Object value = field.get(arr[i]);
                    table.addCell(value.toString());
                } catch (NoSuchFieldException | IllegalAccessException e) {
                    e.printStackTrace();
                }
            }
            table.completeRow();
        }
    }

    private void writeTableHeader(PdfPTable table, String[] header) {
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(Color.DARK_GRAY);
        cell.setPadding(5);
        Font font = FontFactory.getFont(FontFactory.HELVETICA);
        font.setColor(Color.WHITE);
        for(int i=0;i<header.length;i++){
            cell.setPhrase(new Phrase(header[i], font));
            table.addCell(cell);
        }
        table.completeRow();
    }

    private String[] getFieldsFromCollection(Collection<?> objects) {

        if(objects == null || objects.isEmpty()){
            return new String[0];
        }
        Field[] fields = objects.toArray()[0].getClass().getDeclaredFields();
        String[] headers = new String[fields.length];
        for(int i = 0; i < fields.length ; i++){
            headers[i]= fields[i].getName();
        }
        return headers;
    }


    private String[] convertCamelCaseToUpperCase(String[] strings){
        String[] converted = new String[strings.length];
        String regex = "([a-z])([A-Z]+)";
        String replacement = "$1 $2";
        for(int i = 0; i < strings.length ; i++){
            converted[i] = strings[i].replaceAll(regex,replacement).toUpperCase();
        }
        return converted;
    }


}
