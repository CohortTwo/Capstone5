package com.ntuc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ntuc.model.Users;

public interface UserRepository extends JpaRepository<Users, Integer>{

	Users getUserByUsername(String username);

	
}
