package com.demo.datarepository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.datamodel.Department;

public interface DepartmentRepository extends JpaRepository<Department, Integer>{

}
