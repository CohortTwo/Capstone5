
$(document).ready(function(){
	
	$(".form-username").val("Username...");
	$(".form-password").val("Password...");
	
});