package com.apparel.controller;


import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.apparel.model.UserPDFExporter;
import com.apparel.model.Users;
import com.apparel.repository.UserRepository;
import com.lowagie.text.DocumentException;



@Controller
public class UserController {

	@Autowired
	private UserRepository userrepo;
	
	
	@GetMapping("/user")
	public String listUser(Model model) {
		Iterable<Users> listUser = userrepo.findAll();
		model.addAttribute("listUser",listUser);
		return "users";
	}
	
	@GetMapping("/user/new")
	public String showNewUserForm(Model model) {
		model.addAttribute("user", new Users());
		return "users_form";
		
	}
	
	@PostMapping("/user/save")
	public String saveUser(Users user, HttpServletRequest request) {
		userrepo.save(user);
		return "redirect:/user";
	}
	
	@GetMapping("/user/edit/{id}") 
	public String showEditUserForm(@PathVariable("id") Integer id, Model model) {
		Users user = userrepo.findById(id).get();
		model.addAttribute("user", user);
		return "users_form";
	}
	
	@GetMapping("/user/delete/{id}")
	public String deleteUser(@PathVariable("id") Integer id, Model model) {
		userrepo.deleteById(id);
		return "redirect:/user";
	}
	
	@GetMapping("/user/export/pdf")
    public void exportToPDF(HttpServletResponse response) throws DocumentException, IOException {
        response.setContentType("application/pdf");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());
         
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=users_" + currentDateTime + ".pdf";
        response.setHeader(headerKey, headerValue);
         
        List<Users> listUsers = (List<Users>) userrepo.findAll();
         
       UserPDFExporter exporter = new UserPDFExporter(listUsers);
       exporter.export(response);
    }
	
	@GetMapping("/user/export/csv")
    public void exportToCSV(HttpServletResponse response) throws IOException {
        response.setContentType("text/csv");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        String currentDateTime = dateFormatter.format(new Date());
         
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
        response.setHeader(headerKey, headerValue);
         
        List<Users> listUsers = userrepo.findAll();
 
        ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
        String[] csvHeader = {"User ID", "Username", "Password", "Roles", "Enabled"};
        String[] nameMapping = {"id", "username", "password", "roles", "enabled"};
         
        csvWriter.writeHeader(csvHeader);
         
        for (Users user : listUsers) {
            csvWriter.write(user, nameMapping);
        }
         
        csvWriter.close();
         
    }
	
}
