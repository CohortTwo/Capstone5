package com.ntuc.repository;

import com.ntuc.model.Department;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface DepartmentRepository extends JpaRepository<Department,Long> {

    @Query("SELECT d FROM Department d WHERE "
            + " CONCAT(d.deptId,d.deptName)"
            +  " LIKE %?1%" )
    Page<Department> findAll(String keyword, Pageable pageable);

    List<Department> findAllByDeptNameContaining(String nameLike);
}
