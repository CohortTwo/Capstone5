package com.ntuc.controller;

import com.ntuc.repository.DepartmentRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class DepartmentController {
	@Autowired
	private DepartmentRepository repo;

	@ModelAttribute("listDepartments")
	public void listJobs(Model model) {
		model.addAttribute("listDepartments", repo.findAll());
	}
}
