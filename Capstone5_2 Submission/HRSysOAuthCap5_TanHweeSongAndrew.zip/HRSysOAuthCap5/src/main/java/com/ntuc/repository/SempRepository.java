package com.ntuc.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


import com.ntuc.model.Semps;

public interface SempRepository extends JpaRepository<Semps, Integer> {

	
	/*
	 * String q =
	 * "select Semps.id, Semps.name, Semps.price, Semps.dept_id, Semp_details.name,Semp_details.value from Semps  INNER JOIN Semp_details on Semps.id=Semp_details.emp_id "
	 * + "where Semp_details.value = :keyword";
	 * 
	 * @Query(value=q, nativeQuery=true)
	 */
	@Query("SELECT p FROM Semps p WHERE "
	+ " CONCAT(p.id, p.name, p.price, p.sdept)" 
	+  " LIKE %?1%" )
	public Page<Semps> findAll(String keyword,Pageable pageable);
	
	

	 
	}


