package springauth.controller;

import springauth.repository.*;
import springauth.model.*;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;


@Controller
public class DeptController {

		
		@Autowired
		private DeptRepository repo;
		
		@GetMapping("/depts")
		public String listDepts(Model model) {
			List<Dept> listdepts = repo.findAll();
			model.addAttribute("listdepts",listdepts);
			return "depts";
		}
		
		@GetMapping("/depts/new")
		public String ShowDeptNewForm(Model model) {
			model.addAttribute("dept", new Dept());
			
			return "dept_form";
							
		}
		
		@PostMapping("/depts/save")
		public String saveCategory(Dept dept) {
			repo.save(dept);
			return "redirect:/depts";
		}
				
	}

	
