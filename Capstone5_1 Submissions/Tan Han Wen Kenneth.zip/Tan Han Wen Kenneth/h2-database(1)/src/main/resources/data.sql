INSERT INTO 
	TBL_EMPLOYEES (first_name, last_name, email) 
VALUES
  	('okay', 'computing', 'okaycomputing@gmail.com'),
  	('spring', 'h2db', 'spring.h2db@gmail.com'),
  	('springboot', 'in-memory-db', 'springboot.inmemory@gmail.com');
  	