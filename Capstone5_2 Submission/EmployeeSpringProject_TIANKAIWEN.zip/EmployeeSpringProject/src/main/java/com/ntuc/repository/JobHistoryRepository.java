package com.ntuc.repository;

import com.ntuc.model.JobHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface JobHistoryRepository extends JpaRepository<JobHistory,Long> {
}
