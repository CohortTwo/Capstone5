package com.ntuc.controller.view;

import com.ntuc.model.Department;
import com.ntuc.model.DepartmentExportDTO;
import com.ntuc.model.Employee;
import com.ntuc.service.DepartmentService;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.Writer;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Controller
public class DepartmentViewController {

    @Autowired
    private DepartmentService departmentService;

    @GetMapping("/dept/new")
    public String createDepartmentPage(Model model){
        model.addAttribute("department", new Department());
        return "dept/deptnew";
    }

    @GetMapping("/dept/view")
    public String viewDepartmentPage(Model model){
        model.addAttribute("departmentList", departmentService.showDepartments());
        return "dept/deptview";
    }

    @GetMapping("/dept/view/page")
    public String viewDepartmentPageByPaging(Model model,
                                             @RequestParam("pageNo")Optional<Integer> pageNo,
                                             @RequestParam("dir")Optional<String> dir,
                                             @RequestParam("field")Optional<String> field,
                                             @RequestParam("keyword")Optional<String> keyword){
        int currentPage = pageNo.orElse(1);
        String direction = dir.orElse("asc");
        String fields = field.orElse("deptId");
        String keywords = keyword.orElse("");
        String reverseDirection = direction.equalsIgnoreCase("asc") ? "desc" : "asc";
        Page<Department> deptPage = departmentService.showDepartmentsByPaging(currentPage,direction,fields,keywords);
        int totalPages = deptPage.getTotalPages();
        model.addAttribute("deptPage", deptPage);
        model.addAttribute("totalElements",deptPage.getTotalElements());
        model.addAttribute("currentPage",currentPage);
        model.addAttribute("totalPages", totalPages);
        model.addAttribute("direction",direction);
        model.addAttribute("reverseDirection", reverseDirection);
        model.addAttribute("fields",fields);
        model.addAttribute("keywords",keywords);
        return "dept/deptviewpaging";
    }

    @PostMapping("/dept/save")
    public String createDepartment(Department department){
        departmentService.addDepartment(department);
        return "redirect:/";
    }

    @GetMapping("/dept/export/csv")
    public void exportDepartmentToCsv(@RequestParam("keyword")String keyword,
                                      HttpServletResponse response) throws IOException {
        String fileName = "dept_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("ddMMyyyyHHmmss")) + ".csv";

        response.setContentType("text/csv");
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename=\"" + fileName + "\"");
        List<Department> departments = departmentService.showDepartmentsByNameLike(keyword);
        departmentService.exportToCsv(response.getWriter(),departments);
    }

    @GetMapping("/dept/export/pdf")
    public void exportEmployeeToPdf(@RequestParam("keyword")String keyword,
                                    HttpServletResponse response) throws IOException {
        final String fileName = "dept_" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("ddMMyyyyHHmmss")) + ".pdf";
        response.setContentType("application/pdf");
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename=\"" + fileName + "\"");
        List<Department> departments = departmentService.showDepartmentsByNameLike(keyword);
        departmentService.exportToPdf(response.getOutputStream(),departments);
    }
}
