package com.ntuc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ntuc.model.*;

@Repository
public interface CategoryRepository extends JpaRepository<Category, Integer> {

}
