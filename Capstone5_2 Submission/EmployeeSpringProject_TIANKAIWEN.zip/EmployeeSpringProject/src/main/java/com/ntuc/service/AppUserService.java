package com.ntuc.service;

import com.ntuc.security.model.AppUser;

import java.util.Optional;

public interface AppUserService {
    AppUser findAppUserByUsername(String username);

    boolean validatePassword(String password, String confirmPassword);

    void updateAppUserWithNewPassword(AppUser user, String password);
}
