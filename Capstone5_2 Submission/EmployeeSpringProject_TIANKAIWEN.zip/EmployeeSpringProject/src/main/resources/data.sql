insert into department values (1,'IT');
insert into department values (2,'Operations');
insert into department values (3,'Business');
insert into department values (4,'Customer Service');
insert into department values (5,'Engineering');
insert into department values (6,'Support');
insert into department values (7,'Finance');
insert into department values (8,'Audit');
insert into department values (9,'Transport');
insert into department values (10,'Marketing');
insert into department values (11,'HR');




insert into employee (emp_id,name,designation,dob,dept_id) values (1 ,'Tom','CEO','1955-02-12',1);
insert into employee (emp_id,name,designation,dob,dept_id) values (2 ,'Dick','Director','1987-02-12',1);
insert into employee (emp_id,name,designation,dob,dept_id) values (3 ,'Harry','Sr Director','1989-02-12',1);
insert into employee (emp_id,name,designation,dob,dept_id) values (4 ,'Mary','Employee','1988-02-12',1);
insert into employee (emp_id,name,designation,dob,dept_id) values (5 ,'Bob','Architect','1966-03-11',1);
insert into employee (emp_id,name,designation,dob,dept_id) values (6 ,'Tom','Analyst','1988-02-12',1);
insert into employee (emp_id,name,designation,dob,dept_id) values (7 ,'Tom','Analyst','1988-02-12',2);
insert into employee (emp_id,name,designation,dob,dept_id) values (8 ,'Tom','Manager','1988-02-12',3);
insert into employee (emp_id,name,designation,dob,dept_id) values (9 ,'Tom','Analyst','1988-02-12',5);
insert into employee (emp_id,name,designation,dob,dept_id) values (10,'Tom','Manager','1988-02-12',4);
insert into employee (emp_id,name,designation,dob,dept_id) values (11,'Tom','Analyst','1988-02-12',1);
insert into employee (emp_id,name,designation,dob,dept_id) values (12,'Tom','Manager','1988-02-12',6);
insert into employee (emp_id,name,designation,dob,dept_id) values (13,'Tom','Analyst','1988-02-12',2);
insert into employee (emp_id,name,designation,dob,dept_id) values (14,'Tom','Manager','1988-02-12',3);
insert into employee (emp_id,name,designation,dob,dept_id) values (15,'Tom','Analyst','1988-02-12',2);
insert into employee (emp_id,name,designation,dob,dept_id) values (16,'Tom','Manager','1988-02-12',3);
insert into employee (emp_id,name,designation,dob,dept_id) values (17,'Tom','Analyst','1988-02-12',1);
insert into employee (emp_id,name,designation,dob,dept_id) values (18,'Tom','Manager','1988-02-12',6);
insert into employee (emp_id,name,designation,dob,dept_id) values (19,'Tom','Analyst','1988-02-12',1);
insert into employee (emp_id,name,designation,dob,dept_id) values (20,'Tom','Sr Analyst','1988-02-12',1);
insert into employee (emp_id,name,designation,dob,dept_id) values (21,'Tom','Sr Analyst','1988-02-12',2);
insert into employee (emp_id,name,designation,dob,dept_id) values (22,'Tom','Sr Analyst','1988-02-12',3);
insert into employee (emp_id,name,designation,dob,dept_id) values (23,'Tom','Temp','1988-02-12',11);
insert into employee (emp_id,name,designation,dob,dept_id) values (24,'Tom','Temp','1988-02-12',10);
insert into employee (emp_id,name,designation,dob,dept_id) values (25,'Tom','Manager','1988-02-12',1);
insert into employee (emp_id,name,designation,dob,dept_id) values (26,'Tom','Analyst','1988-02-12',9);
insert into employee (emp_id,name,designation,dob,dept_id) values (27,'Tom','Analyst','1988-02-12',8);
insert into employee (emp_id,name,designation,dob,dept_id) values (28,'Tom','Sr Analyst','1988-02-12',8);
insert into employee (emp_id,name,designation,dob,dept_id) values (29,'Tom','Analyst','1988-02-12',2);
insert into employee (emp_id,name,designation,dob,dept_id) values (30,'Tom','Sr Analyst','1988-02-12',6);
insert into employee (emp_id,name,designation,dob,dept_id) values (31,'Tom','Manager','1988-02-12',7);
insert into employee (emp_id,name,designation,dob,dept_id) values (32,'Tom','Analyst','1988-02-12',1);
insert into employee (emp_id,name,designation,dob,dept_id) values (33,'Tom','Sr Analyst','1988-02-12',1);
insert into employee (emp_id,name,designation,dob,dept_id) values (34,'Tom','Manager','1988-02-12',8);
insert into employee (emp_id,name,designation,dob,dept_id) values (35,'Tom','Analyst','1988-02-12',9);
insert into employee (emp_id,name,designation,dob,dept_id) values (36,'Tom','Sr Analyst','1988-02-12',10);
insert into employee (emp_id,name,designation,dob,dept_id) values (37,'Tom','Analyst','1988-02-12',11);





insert into employee_details (emp_details_id,area_code,phone_number) values (1 ,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (2 ,'+122','1294985835');
insert into employee_details (emp_details_id,area_code,phone_number) values (3 ,'+566','948372232380');
insert into employee_details (emp_details_id,area_code,phone_number) values (4 ,'+1','8757430380');
insert into employee_details (emp_details_id,area_code,phone_number) values (5 ,'+102','32847373838');
insert into employee_details (emp_details_id,area_code,phone_number) values (6 ,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (7 ,'+65','94847380');
insert into employee_details (emp_details_id,area_code,phone_number) values (8 ,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (9 ,'+65','94857380');
insert into employee_details (emp_details_id,area_code,phone_number) values (10,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (11,'+65','94867380');
insert into employee_details (emp_details_id,area_code,phone_number) values (12,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (13,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (14,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (15,'+65','92847588');
insert into employee_details (emp_details_id,area_code,phone_number) values (16,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (17,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (18,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (19,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (20,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (21,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (22,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (23,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (24,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (25,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (26,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (27,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (28,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (29,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (30,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (31,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (32,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (33,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (34,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (35,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (36,'+65','94837380');
insert into employee_details (emp_details_id,area_code,phone_number) values (37,'+65','94837380');


insert into app_user (app_user_id,username,password,is_enabled,is_locked,password_expiry_date,account_expiry_date) values (1,'admin','{bcrypt}$2y$12$k3yNTkzh2ejGpinjwlMP0u39gI/UFBOcfNIMJhGWGXU97EnCqQ4WK',1,0,'2021-5-19','2021-9-17');
insert into app_user (app_user_id,username,password,is_enabled,is_locked,password_expiry_date,account_expiry_date) values (2,'employee','{bcrypt}$2y$12$Kh81TLYXMVeMxOHrOgubKuFsW7ipZjpt5ZO45DBSqxJ3WBSp0xo2K',1,0,'2021-07-05','2022-09-03');



insert into app_role values (1,'Admin');
insert into app_role values (2,'Operator');
insert into app_role values (3,'Employee');


insert into app_user_app_role_map values (1,1);
insert into app_user_app_role_map values (1,2);
insert into app_user_app_role_map values (1,3);
insert into app_user_app_role_map values (2,3);


