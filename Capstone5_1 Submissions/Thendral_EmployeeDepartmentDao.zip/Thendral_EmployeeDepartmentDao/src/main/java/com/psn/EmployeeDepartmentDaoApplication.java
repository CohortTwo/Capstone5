package com.psn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication

public class EmployeeDepartmentDaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeDepartmentDaoApplication.class, args);
	}

}
