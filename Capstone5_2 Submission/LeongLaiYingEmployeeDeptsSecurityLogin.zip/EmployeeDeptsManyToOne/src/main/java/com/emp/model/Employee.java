package com.emp.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.emp.model.Contact;

@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String ename;
    private String job;
    private int mgr;
    @ManyToOne
	@JoinColumn(name= "depts_id")
    private Depts depts;
    private int sal;
    private int comm;
    private String hdate;
    
    @OneToMany(mappedBy ="employee", cascade = CascadeType.ALL)
	private List<Contact> contacts = new ArrayList<>();
    
	
	public Employee() {
	
	}

	public int getId() {
		return id;
	}
	public List<Contact> getContacts() {
		return contacts;
	}

	public void setContacts(List<Contact> contacts) {
		this.contacts = contacts;
	}

	public void setId(int id) {
		this.id = id;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public int getMgr() {
		return mgr;
	}
	public void setMgr(int mgr) {
		this.mgr = mgr;
	}

	public Depts getDepts() {
		return depts;
	}

	public void setDepts(Depts depts) {
		this.depts = depts;
	}

	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	public int getComm() {
		return comm;
	}
	public void setComm(int comm) {
		this.comm = comm;
	}
	public String getHdate() {
		return hdate;
	}
	public void setHdate(String hdate) {
		this.hdate = hdate;
	}
	public void setContact(Integer id,String contact) {
		this.contacts.add(new Contact(id,contact,this));
	
	}

	public void addContact(String contact) {
		this.contacts.add(new Contact(id,contact,this));
	}
	
	public void removeContact(int id) {
		this.contacts.remove(id);

	}
}

