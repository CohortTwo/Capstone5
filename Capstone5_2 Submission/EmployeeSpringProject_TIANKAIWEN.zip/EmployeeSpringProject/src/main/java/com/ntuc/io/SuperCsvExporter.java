package com.ntuc.io;

import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import java.io.Writer;
import java.lang.reflect.Field;
import java.util.Collection;

public class SuperCsvExporter<T> implements CollectionExportable<T,Void>{

    private final Writer writer;

    public SuperCsvExporter(Writer writer){
        this.writer = writer;
    }

    @Override
    public Void export(Collection<T> objects) {
        try (
             ICsvBeanWriter csvBeanWriter = new CsvBeanWriter(writer, CsvPreference.STANDARD_PREFERENCE);

        ) {
            String [] fields = getFieldsFromCollection(objects);
            String [] headers = convertCamelCaseToUpperCase(fields);
            csvBeanWriter.writeHeader(headers);
            for(T o : objects){
                csvBeanWriter.write(o,fields);
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }

        return null;
    }

    private String[] getFieldsFromCollection(Collection<?> objects) {

        if(objects == null || objects.isEmpty()){
            return new String[0];
        }
        Field[] fields = objects.toArray()[0].getClass().getDeclaredFields();
        String[] headers = new String[fields.length];
        for(int i = 0; i < fields.length ; i++){
            headers[i]= fields[i].getName();
        }
        return headers;
    }


    private String[] convertCamelCaseToUpperCase(String[] strings){
        String[] converted = new String[strings.length];
        String regex = "([a-z])([A-Z]+)";
        String replacement = "$1 $2";
        for(int i = 0; i < strings.length ; i++){
            converted[i] = strings[i].replaceAll(regex,replacement).toUpperCase();
        }
        return converted;
    }
}
