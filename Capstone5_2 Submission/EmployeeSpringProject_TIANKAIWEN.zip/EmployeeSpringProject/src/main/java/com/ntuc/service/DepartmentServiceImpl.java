package com.ntuc.service;

import com.ntuc.io.CollectionExportable;
import com.ntuc.io.OpenPdfTableExporter;
import com.ntuc.io.SuperCsvExporter;
import com.ntuc.model.Department;
import com.ntuc.model.DepartmentExportDTO;
import com.ntuc.repository.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import javax.servlet.ServletOutputStream;
import java.io.OutputStream;
import java.io.Writer;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    private DepartmentRepository departmentRepository;

    @Autowired
    public DepartmentServiceImpl(DepartmentRepository DepartmentRepository){
        this.departmentRepository = DepartmentRepository;
    }

    @Override
    public List<Department> showDepartments() {
        return departmentRepository.findAll();
    }

    @Override
    public Optional<Department> showDepartmentById(Long id) {
        return departmentRepository.findById(id);
    }

    @Override
    public Long addDepartment(Department Department) {
        return departmentRepository.save(Department).getDeptId();
    }

    @Override
    public void modifyDepartment(Department Department, Long id) {
        departmentRepository.saveAndFlush(Department);
    }

    @Override
    public void removeDepartment(Long id) {
        departmentRepository.deleteById(id);
    }

    @Override
    public Page<Department> showDepartmentsByPaging(int pageNo, String dir, String field, String keyword){
        Sort sort = Sort.by(field);

        if(field !=null && !field.isEmpty()){
            sort = Sort.by(field);
            if(dir != null && !dir.isEmpty()) {
                if(dir.equalsIgnoreCase("asc"))
                    sort = sort.ascending();
                else
                    sort = sort.descending();
            }
        }

        Pageable pageable = PageRequest.of(pageNo-1, 5,sort);
        if(keyword!=null && !keyword.isEmpty()) {
            return departmentRepository.findAll(keyword,pageable);
        }
            return departmentRepository.findAll(pageable);
    }

    @Override
    public List<Department> showDepartmentsByNameLike(String nameLike) {
        if(nameLike.isEmpty() || nameLike == null){
            return departmentRepository.findAll();
        }
        return departmentRepository.findAllByDeptNameContaining(nameLike);
    }

    @Override
    public void exportToCsv(Writer writer, List<Department> departments){
        List<DepartmentExportDTO> departmentExportDTOS = departments.stream().map(DepartmentExportDTO::new).collect(Collectors.toList());
        CollectionExportable<DepartmentExportDTO,Void> exportable = new SuperCsvExporter(writer);
        exportable.export(departmentExportDTOS);
        return;
    }

    @Override
    public void exportToPdf(OutputStream os, List<Department> departments) {
        List<DepartmentExportDTO> departmentExportDTOS = departments.stream().map(DepartmentExportDTO::new).collect(Collectors.toList());
        CollectionExportable<DepartmentExportDTO,Void> exportable = new OpenPdfTableExporter(os, Department.class);
        exportable.export(departmentExportDTOS);
        return;
    }
}
