package com.ntuc.security.model;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
public class AppRole {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long appRoleId;

    @Column
    private String roleName;

    @ManyToMany(mappedBy = "appRoles", fetch = FetchType.LAZY)
    private Set<AppUser> appUsers = new HashSet<>();

    public void addAppUser(AppUser appUser){
        appUsers.add(appUser);
        appUser.getAppRoles().add(this);
    }

    public void removeAppUser(AppUser appUser){
        appUsers.remove(appUser);
        appUser.getAppRoles().remove(this);
    }

    public AppRole(Long appRoleId, String roleName) {
        this.appRoleId = appRoleId;
        this.roleName = roleName;
    }

    public AppRole() {
    }

    public Long getAppRoleId() {
        return appRoleId;
    }

    public void setAppRoleId(Long appRoleId) {
        this.appRoleId = appRoleId;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
}
