package com.emp.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.emp.model.Employee;


public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

//	@Query("SELECT e FROM Employee e where CONCAT(e.id, e.ename, e.job, e.mgr, e.sal, e.comm, e.hdate, e.depts.dname) like %?1%" )
//	@Query("select e from Employee e join e.contact c where c.contact= :keyword and CONCAT(e.id, e.ename, e.job, e.mgr, e.sal, e.comm, e.hdate, e.depts.dname) like %?1%" )
	//SELECT addresses.description 
	//FROM place p JOIN p.addresses addresses
	//@Query("SELECT e FROM Employee e inner join e.contact contact where contact.id in :contactIds and CONCAT(e.id, e.ename, e.job, e.mgr, e.sal, e.comm, e.hdate, e.depts.dname, e.contact) like %?1%" )
	@Query(value = "select e, c from Employee e join contact c on e.id = c.employee_id where CONCAT(e.id, e.ename, e.job, e.mgr, e.sal, e.comm, e.hdate, e.depts.dname, c.contact) like %?1%",nativeQuery = true)
	public Page<Employee> findAll(String keyword,Pageable pageable);
	
	
//  @Query(value = "UPDATE topic set name =:name, where id = :id",
//  nativeQuery = true)
//	@Query("SELECT p FROM Product p WHERE p.name LIKE %?1%"
//			+ " OR p.brand LIKE %?1%"
//			+ " OR p.madein LIKE %?1%"	)
//	public List<Product> findAll(String keyword);
	
	//@Query(value = "delete from contact where employee_id = :id", nativeQuery = true)
	//public void deleteContactbyId(int id);


}
