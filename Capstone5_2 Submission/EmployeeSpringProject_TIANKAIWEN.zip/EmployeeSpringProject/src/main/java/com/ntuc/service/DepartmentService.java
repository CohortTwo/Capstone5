package com.ntuc.service;

import com.ntuc.model.Department;
import org.springframework.data.domain.Page;

import javax.servlet.ServletOutputStream;
import java.io.OutputStream;
import java.io.Writer;
import java.util.List;
import java.util.Optional;

public interface DepartmentService {
    List<Department> showDepartments();

    Optional<Department> showDepartmentById(Long id);

    Long addDepartment(Department Department);

    void modifyDepartment(Department Department, Long id);

    void removeDepartment(Long id);

    Page<Department> showDepartmentsByPaging(int pageNo, String dir, String field, String keyword);

    List<Department> showDepartmentsByNameLike(String nameLike);

    void exportToCsv(Writer writer, List<Department> departments);

    void exportToPdf(OutputStream outputStream, List<Department> departments);
}
