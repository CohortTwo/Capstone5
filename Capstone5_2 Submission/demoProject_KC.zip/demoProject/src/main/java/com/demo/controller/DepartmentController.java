package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.demo.model.Department;
import com.demo.repository.DepartmentRepo;

@Controller
public class DepartmentController {
	
	@Autowired
	private DepartmentRepo deptrepo;
	
	@GetMapping("/departments")
	public String listDepartments(Model model) {
		List<Department> listDepartments = deptrepo.findAll();
		model.addAttribute("listDepartments", listDepartments);
		return "departments";
	}
	
	@GetMapping("/departments/new")
	public String showDepartmentNewForm(Model model) {
		List<Department> listDepartments = deptrepo.findAll();
		model.addAttribute("listDepartments", listDepartments);
		model.addAttribute("department", new Department());
		return "department_form";
	}
	
	@PostMapping("/departments/save")
	public String saveDepartment(Department department) {
		deptrepo.save(department);
		return "redirect:/";
	}
}
