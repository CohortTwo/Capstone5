package com.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.model.UserRole;

public interface RoleRepo extends JpaRepository<UserRole, Integer>{

}
