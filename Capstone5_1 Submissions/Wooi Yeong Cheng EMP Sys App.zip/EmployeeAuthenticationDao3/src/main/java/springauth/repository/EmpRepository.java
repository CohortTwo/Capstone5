package springauth.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import springauth.model.Emp;

public interface EmpRepository extends JpaRepository<Emp, Long> {

	
//	@Query("SELECT p FROM Product p WHERE p.name LIKE %?1%"
//			+ " OR p.brand LIKE %?1%"
//			+ " OR p.madein LIKE %?1%")
//	public List<Product> findAll(String keyword);
	
	@Query("SELECT p FROM Emp p WHERE "
			+ " CONCAT(p.id, p.name, p.madein, p.madein, p.price)" 
			+  " LIKE %?1%" )
	public Page<Emp> findAll(String keyword,Pageable pageable);
	
}
