package com.ntuc.model;

import java.time.LocalDate;
import java.util.Objects;

public class EmployeeExportDTO {

    private Long empId;
    private String name;
    private LocalDate dob;
    private String designation;
    private String deptName;


    public EmployeeExportDTO(Employee employee){
        this.empId = employee.getEmpId();
        this.name = employee.getName();
        this.dob = employee.getDob();
        this.designation = employee.getDesignation();
        this.deptName = employee.getDepartment().getDeptName();
    }

    public Long getEmpId() {
        return empId;
    }

    public void setEmpId(Long empId) {
        this.empId = empId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EmployeeExportDTO that = (EmployeeExportDTO) o;
        return Objects.equals(empId, that.empId) &&
                Objects.equals(name, that.name) &&
                Objects.equals(dob, that.dob) &&
                Objects.equals(designation, that.designation) &&
                Objects.equals(deptName, that.deptName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(empId, name, dob, designation, deptName);
    }

    @Override
    public String toString() {
        return "EmployeeExportDTO{" +
                "empId=" + empId +
                ", name='" + name + '\'' +
                ", dob=" + dob +
                ", designation='" + designation + '\'' +
                ", deptName='" + deptName + '\'' +
                '}';
    }
}
